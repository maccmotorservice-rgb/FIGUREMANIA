#!/usr/bin/env python3
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from xml.etree import ElementTree as ET
import sys
r=Path(__file__).resolve().parent
out=r/'servidor';(out/'Widget').mkdir(parents=True,exist_ok=True)
name='AlmaTV_6.0_America_20261021.zip';p=out/'Widget'/name
with ZipFile(str(p),'w',ZIP_DEFLATED) as z:
 for f in sorted((r/'app').rglob('*')):
  if f.is_file():z.write(str(f),str(f.relative_to(r/'app')))
ip=sys.argv[1] if len(sys.argv)>1 else '192.168.1.30'
rsp=ET.Element('rsp',stat='ok');lst=ET.SubElement(rsp,'list');w=ET.SubElement(lst,'widget',id='AlmaTV60')
ET.SubElement(w,'title').text='Alma TV 6.0';ET.SubElement(w,'compression',type='zip',size=str(p.stat().st_size));ET.SubElement(w,'description').text='Alma TV 6.0 estilo tvOS';ET.SubElement(w,'download').text='http://%s/Widget/%s'%(ip,name)
ET.ElementTree(rsp).write(str(out/'widgetlist.xml'),encoding='utf-8',xml_declaration=True)
print('LISTO:',p);print('IP:',ip);print('Catalogo: http://%s/widgetlist.xml'%ip)
