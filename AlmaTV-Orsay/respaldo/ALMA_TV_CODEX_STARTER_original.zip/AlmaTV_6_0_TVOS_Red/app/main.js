var Alma={api:null,zone:'nav',index:0,mode:'home',scale:100,shiftY:0,tvIp:'192.168.1.249',netOK:false,timerEnd:0,timerMinutes:10,timerActive:false,saveBeforeCal:100,shiftBeforeCal:0,
apps:[
 {name:'Netflix',img:'netflix.jpg',type:'dial',target:'Netflix',subtitle:'Abrir Netflix'},
 {name:'YouTube',img:'youtube.jpg',type:'dial',target:'YouTube',subtitle:'Abrir YouTube'},
 {name:'Prime Video',img:'prime.jpg',type:'web',target:'https://www.primevideo.com',subtitle:'Abrir sitio web'},
 {name:'Navegador',img:'browser.jpg',type:'web',target:'https://example.com',subtitle:'Abrir navegador'},
 {name:'Smart Hub',img:'hub.jpg',type:'exit',subtitle:'Salir al sistema'},
 {name:'Más apps',img:'more.jpg',type:'more',subtitle:'Herramientas y apps'}
],
tools:[{name:'Reloj',type:'clock'},{name:'Temporizador',type:'timer'},{name:'Calendario',type:'calendar'},{name:'Red local',type:'network'},{name:'Clima',type:'weather'},{name:'Salvapantallas',type:'saver'}],
onLoad:function(){try{this.api=new Common.API.Widget();this.api.sendReadyEvent();}catch(ex){}
 try{var scale=localStorage.getItem('alma60_scale'),offset=localStorage.getItem('alma60_y');if(scale){this.scale=parseInt(scale,10)||100;}if(offset){this.shiftY=parseInt(offset,10)||0;}}catch(ex){}
 document.onkeydown=function(e){return Alma.key(e||window.event);};
 this.applyScale();this.draw();this.tick();this.checkNetwork();
},onUnload:function(){},
applyScale:function(){var el=document.getElementById('interface');el.style.webkitTransform='translateY('+this.shiftY+'px) scale('+(this.scale/100)+')';el.style.transform='translateY('+this.shiftY+'px) scale('+(this.scale/100)+')';},
clockValue:function(){var d=new Date();return d.getHours()+':'+('0'+d.getMinutes()).slice(-2);},
dateValue:function(){var d=new Date();return ('0'+d.getDate()).slice(-2)+'/'+('0'+(d.getMonth()+1)).slice(-2);},
weekName:function(d){return ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'][d.getDay()];},
tick:function(){var d=new Date();document.getElementById('clock').innerHTML=this.clockValue();
 if(this.mode==='saver'){document.getElementById('saverClock').innerHTML=this.clockValue();document.getElementById('saverDate').innerHTML=this.weekName(d)+', '+this.dateValue();
 var x=350+(d.getMinutes()%4)*60,y=235+(d.getMinutes()%3)*28;document.getElementById('saverClock').style.left=x+'px';document.getElementById('saverClock').style.top=y+'px';document.getElementById('saverDate').style.left=x+'px';document.getElementById('saverDate').style.top=(y+112)+'px';}
 if(this.mode==='clock'){var x=document.getElementById('liveClock');if(x)x.innerHTML=this.clockValue();}
 if(this.mode==='timer'||this.timerActive){var ms=Math.max(0,this.timerEnd-d.getTime()),s=Math.ceil(ms/1000);if(this.timerActive){if(!s){this.timerActive=false;}var m=Math.floor(s/60);var sec=s%60;var z=(m<10?'0':'')+m+':'+(sec<10?'0':'')+sec;var text=document.getElementById('countdown');if(text)text.innerHTML=z;}}
 this.fillTools();var self=this;setTimeout(function(){self.tick();},15000);
},
checkNetwork:function(){var x=new XMLHttpRequest(),self=this;try{x.open('GET','http://'+this.tvIp+':8080/ws/app/YouTube',true);x.onreadystatechange=function(){if(x.readyState===4){self.netOK=x.status===200;document.getElementById('netLabel').innerHTML=self.netOK?'Red local: OK':'Red local: sin verificar';self.fillTools();}};x.send(null);}catch(ex){document.getElementById('netLabel').innerHTML='Red local: sin verificar';}},
fillTools:function(){var row=document.getElementById('toolStrip');if(!row)return;
 var d=new Date(),val=[''+this.clockValue(),this.timerActive?'Activo':this.timerMinutes+' min',''+this.dateValue(),this.netOK?'Conectada':'Sin verificar','Consultar','Iniciar'];
 var html='';for(var i=0;i<this.tools.length;i++)html+='<div class="toolTile'+(this.zone==='tools'&&this.index===i?' sel':'')+'" id="tl'+i+'"><div class="toolName">'+this.tools[i].name+'</div><div class="toolValue">'+val[i]+'</div></div>';
 row.innerHTML=html;
},
draw:function(){for(var i=0;i<4;i++){var el=document.getElementById('nav'+i);el.className='topItem'+(this.zone==='nav'&&i===this.index?' sel':'');}
 var h='';for(var j=0;j<this.apps.length;j++){var a=this.apps[j];h+='<div class="appTile'+(this.zone==='apps'&&this.index===j?' sel':'')+'"><img src="assets/'+a.img+'"/><div class="tileLabel">'+a.name+'</div></div>';}
 document.getElementById('appStrip').innerHTML=h;
 this.fillTools();this.updateHero();},
updateHero:function(){var title='Lo mejor, en tu pantalla.',sub='Netflix, YouTube y tus herramientas favoritas en una sola interfaz.',art='hero_red.jpg';
 if(this.zone==='apps'){var a=this.apps[this.index];title=a.name;sub=a.subtitle||'Selecciona y pulsa ENTER.';
 if(a.name==='YouTube'||a.name==='Navegador')art='hero_blue.jpg';else if(a.name==='Prime Video')art='hero_gold.jpg';}
 else if(this.zone==='tools'){title=this.tools[this.index].name;sub='Información útil, accesible con tu control remoto.';art='hero_blue.jpg';}
 else if(this.index===2){title='Herramientas';sub='Reloj, clima, temporizador, calendario y red local.';art='hero_blue.jpg';}
 document.getElementById('headline').innerHTML=title;document.getElementById('subline').innerHTML=sub;document.getElementById('heroBg').style.backgroundImage='url(assets/'+art+')';},
show:function(title,body,mode){document.getElementById('modalTitle').innerHTML=title;document.getElementById('modalBody').innerHTML=body;document.getElementById('overlay').style.display='block';this.mode=mode||'modal';},
close:function(){document.getElementById('overlay').style.display='none';document.getElementById('scaleFrame').style.display='none';document.getElementById('saver').style.display='none';this.mode='home';this.draw();},
launchDial:function(name){var x=new XMLHttpRequest(),self=this;try{x.open('POST','http://'+this.tvIp+':8080/ws/app/'+name,true);x.setRequestHeader('Content-Type','text/plain');x.onreadystatechange=function(){if(x.readyState===4 && x.status!==200 && x.status!==201 && x.status!==204){self.show('Error de conexión','No se pudo iniciar '+name+'. Código HTTP: '+x.status+'. Comprueba la IP del televisor.');}};x.send('');}catch(ex){this.show('Error de conexión','No se pudo iniciar '+name+'. '+ex.message);}},
launchBrowser:function(url){try{if(this.api&&typeof this.api.runWebBrowser==='function')this.api.runWebBrowser(url,'');else this.show('Navegador','Esta versión del sistema no ofrece el navegador desde Alma TV.');}catch(ex){this.show('Navegador','No fue posible abrir el sitio. '+ex.message);}},
activateApp:function(){var a=this.apps[this.index];if(a.type==='dial'){this.launchDial(a.target);}else if(a.type==='web'){this.launchBrowser(a.target);}else if(a.type==='exit'){this.exit();}else if(a.type==='more'){this.zone='tools';this.index=0;this.draw();}},
monthHTML:function(){var d=new Date(), y=d.getFullYear(),m=d.getMonth(),f=new Date(y,m,1).getDay(),limit=new Date(y,m+1,0).getDate();f=(f+6)%7;var mn=['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];var week=['L','M','M','J','V','S','D'],h='<table style="border-collapse:collapse;font-size:21px"><tr>';for(var i=0;i<7;i++)h+='<td style="width:85px;padding:5px;color:#a9bfd6">'+week[i]+'</td>';h+='</tr>';var n=1;for(var row=0;row<6;row++){h+='<tr>';for(var col=0;col<7;col++){var slot=row*7+col;h+='<td style="padding:5px;color:'+(slot>=f&&n<=limit?'white':'#354257')+'">'+(slot>=f&&n<=limit?n++:'·')+'</td>';}h+='</tr>';}return '<div style="font-size:22px;margin-bottom:18px">'+mn[m]+' '+y+'</div>'+h;},
activateTool:function(){var typ=this.tools[this.index].type;
 if(typ==='clock'){this.show('Reloj','<div id="liveClock" style="font-size:92px;margin:20px 0">'+this.clockValue()+'</div><div>'+this.weekName(new Date())+' · '+this.dateValue()+'</div>','clock');}
 else if(typ==='timer'){this.show('Temporizador','<div id="countdown" style="font-size:83px;margin:22px 0">'+this.timerMinutes+':00</div><div id="timerHelp">ARRIBA y ABAJO ajustan los minutos. ENTER inicia.</div>','timer');}
 else if(typ==='calendar'){this.show('Calendario',this.monthHTML());}
 else if(typ==='network'){this.show('Red local','IP de la TV: '+this.tvIp+'<div style="margin-top:15px">Servicio DIAL: '+(this.netOK?'disponible':'sin verificar')+'</div><div class="hint">Esto indica conectividad local, no verifica acceso a internet.</div>');}
 else if(typ==='weather'){this.show('Clima','<div style="font-size:24px;margin:26px 0">No hay datos meteorológicos en tiempo real.</div><div>Presiona ENTER para consultar el clima en el navegador Samsung.</div>','weather');}
 else if(typ==='saver'){this.mode='saver';document.getElementById('saver').style.display='block';this.tickSaverOnce();}
},
tickSaverOnce:function(){var d=new Date();document.getElementById('saverClock').innerHTML=this.clockValue();document.getElementById('saverDate').innerHTML=this.weekName(d)+' · '+this.dateValue();},
settings:function(){this.show('Ajustes de pantalla','<div>Calibrar tamaño: pulsa ENTER.</div><div style="margin-top:14px">Escala actual: '+this.scale+'%</div><div class="hint">Podrás agrandar o reducir el menú sin alterar el sistema Samsung.</div>','settings');},
calibrate:function(){this.saveBeforeCal=this.scale;this.shiftBeforeCal=this.shiftY;document.getElementById('scaleFrame').style.display='block';this.show('Calibración','<div>IZQUIERDA: agrandar · DERECHA: reducir.</div><div>ARRIBA y ABAJO: mover verticalmente.</div><div>ENTER: guardar · RETURN: cancelar.</div><div style="margin-top:17px">Escala: <span id="scaleVal">'+this.scale+'</span>%</div>','calibrate');},
handleKey:function(code){if(this.mode==='saver'){if(code===88||code===45||code===29443||code===13||code===8){this.close();}return true;}
 if(this.mode==='calibrate'){if(code===4||code===37){this.scale=Math.min(110,this.scale+2);}else if(code===5||code===39){this.scale=Math.max(85,this.scale-2);}else if(code===29460||code===38){this.shiftY=Math.max(-30,this.shiftY-4);}else if(code===29461||code===40){this.shiftY=Math.min(30,this.shiftY+4);}else if(code===29443||code===13){try{localStorage.setItem('alma60_scale',''+this.scale);localStorage.setItem('alma60_y',''+this.shiftY);}catch(ex){}this.close();return true;}else if(code===88||code===8){this.scale=this.saveBeforeCal;this.shiftY=this.shiftBeforeCal;this.close();return true;}else if(code===45||code===27){this.exit();return true;}this.applyScale();document.getElementById('scaleVal').innerHTML=''+this.scale;return true;}
 if(this.mode==='weather'){if(code===29443||code===13){this.close();this.launchBrowser('https://www.google.com/search?q=clima');}else if(code===88||code===8){this.close();}else if(code===45||code===27){this.exit();}return true;}
 if(this.mode==='settings'){if(code===29443||code===13){this.calibrate();}else if(code===88||code===8){this.close();}else if(code===45||code===27){this.exit();}return true;}
 if(this.mode==='timer'){if(code===29460||code===38){this.timerMinutes=Math.min(120,this.timerMinutes+5);document.getElementById('countdown').innerHTML=this.timerMinutes+':00';}else if(code===29461||code===40){this.timerMinutes=Math.max(5,this.timerMinutes-5);document.getElementById('countdown').innerHTML=this.timerMinutes+':00';}else if(code===29443||code===13){this.timerEnd=(new Date()).getTime()+this.timerMinutes*60000;this.timerActive=true;this.close();}else if(code===88||code===8){this.close();}else if(code===45||code===27){this.exit();}return true;}
 if(this.mode!=='home'){if(code===88||code===29443||code===13||code===8){this.close();}else if(code===45||code===27){this.exit();}return true;}
 if(code===4||code===37){if(this.index>0)this.index--;this.draw();}
 else if(code===5||code===39){var max=this.zone==='nav'?3:this.zone==='apps'?this.apps.length-1:this.tools.length-1;if(this.index<max)this.index++;this.draw();}
 else if(code===29461||code===40){if(this.zone==='nav'){this.zone='apps';this.index=0;}else if(this.zone==='apps'){this.zone='tools';this.index=Math.min(this.index,this.tools.length-1);}this.draw();}
 else if(code===29460||code===38){if(this.zone==='tools'){this.zone='apps';this.index=Math.min(this.index,this.apps.length-1);}else if(this.zone==='apps'){this.zone='nav';this.index=0;}this.draw();}
 else if(code===29443||code===13){if(this.zone==='nav'){if(this.index===0){this.zone='apps';this.index=0;this.draw();}else if(this.index===1){this.zone='apps';this.index=0;this.draw();}else if(this.index===2){this.zone='tools';this.index=0;this.draw();}else{this.settings();}}else if(this.zone==='apps'){this.activateApp();}else{this.activateTool();}}
 else if(code===88||code===45||code===8||code===27||code===10009){this.exit();}
 else return false;
 return true;},
key:function(e){e=e||window.event;var code=e.keyCode||e.which,used=this.handleKey(code);if(used){if(e.preventDefault)e.preventDefault();e.returnValue=false;return false;}return true;},
exit:function(){try{if(this.api)this.api.sendExitEvent();}catch(ex){}}
};