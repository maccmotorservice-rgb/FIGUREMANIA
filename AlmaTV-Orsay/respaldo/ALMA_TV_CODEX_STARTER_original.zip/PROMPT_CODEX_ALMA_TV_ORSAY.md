# PROMPT MAESTRO — ALMA TV ORSAY (SAMSUNG UN50J5200)

Actúa como un equipo senior de ingeniería de software para Smart TV, diseño de interfaces tvOS, compatibilidad web legacy, integración de protocolos DIAL y QA. Tu misión es transformar un prototipo funcional llamado Alma TV en una aplicación de calidad de producto para mi televisor Samsung UN50J5200 (2015) con sistema Samsung Legacy/Orsay. No entregues otra maqueta visual o prototipo de botones falsos: construye una interfaz cuidada, rápida y navegable con todas las funciones viables conectadas, claramente distinguiendo lo que funciona de lo que la plataforma no permite.

## Entradas y referencias
- Proyecto base adjunto: carpeta AlmaTV_6_0_TVOS_Red (contiene app/, preparar.py, widget.info, config.xml y archivos de instalación). **Lee el código existente antes de editarlo**. No presupongas que su estructura o funciones son correctas: audítalas.
- Referencia visual prioritaria: `referencias/interfaz_objetivo.jpg` (captura de una Smart TV con barra superior muy discreta, hero cinematográfico rojo y dos filas de iconos pequeños). Reproduce composición, escala, espacios y jerarquía visual, NO copias pixel-perfect ni contenidos originales protegidos sin permiso.
- Inspiración de ingeniería/diseño: https://github.com/Gathin23/cleanyourtv ; examina README, launcher, themes y LICENSE MIT, conserva atribución si reutilizas código MIT. **Su código Android (ADB, Java/Kotlin APK, pm disable-user, launcher HOME) NO corre en Orsay**. No conviertas este proyecto en APK ni intentes ejecutar ADB. Recupera únicamente ideas de arquitectura, diseño y enfoque de verificación.

## Hardware y hechos comprobados, NO los vuelvas a adivinar
- TV Samsung **UN50J5200**, año 2015, plataforma **Samsung Orsay / Samsung Legacy**, no Android TV, no Tizen moderno.
- Resolución física Full HD 1920×1080; espacio estándar de diseño para la app Orsay: **1280×720**. La TV presenta recortes/overscan, ya se logró una zona segura con márgenes en una versión previa (3.1). Mantén calibración visual guardable y aplicable a TODAS las pantallas, sin escalado descontrolado.
- Mac con macOS, Python 3.8.9. Servidor Orsay de instalación HTTP puerto **80**, con `widgetlist.xml` y ZIP en `/Widget/`. El usuario usa cuenta `develop` y opción Samsung Apps → `Ajustes IP` → `Sincr. aplicac.`. El archivo `widget.info` antiguo **debe permanecer en texto plano**, no XML. `config.xml` contiene `cpname` único. El identificador en `widgetlist.xml` debe coincidir con el identificador interno. Ya hubo fallos de instalación por cambios en esos archivos.
- Red local comprobada en la última sesión: Mac `192.168.1.30`, TV `192.168.1.249`. Son configurables; no supongas que siempre serán las mismas. No escanees redes externas. La Mac está en la misma Wi-Fi que la TV.
- La TV expone DIAL 2.0 por puerto 8080. **Se comprobó físicamente**: `GET http://192.168.1.249:8080/ws/app/YouTube` y `/Netflix` devuelve `200` y estado, y `POST` a esas rutas abrió **YouTube y Netflix** al instante. Luego Alma TV 3.4 pudo lanzar ambas desde su interfaz. Mantén estas funciones: ENTER debe lanzar con UNA pulsación, sin confirmación repetida.
- API Orsay utilizada: `Common.API.Widget`, `sendReadyEvent()`, `sendExitEvent()` y `runWebBrowser()` (esta última abrió el navegador original y RETURN devolvió a Alma TV). Smart Hub continúa siendo sistema principal; no afirmar que sustituimos Home.
- Códigos reales del control: IZQUIERDA=4, DERECHA=5, ARRIBA=29460, ABAJO=29461, ENTER=29443, RETURN=88, EXIT=45, verde=20, amarillo=21. Añade códigos estándar de teclado solo como fallback y respeta navegación consistente.
- Se deben poder usar Netflix y YouTube nativos. Prime Video NO se confirmó por DIAL; no lo declares funcional hasta verificarlo. El navegador de Samsung puede ser incompatible con servicios actuales.

## Qué no funcionaba antes y debes corregir
1. Pestañas Inicio/Apps/Herramientas/Ajustes cambiaban apenas encabezados, pero mostraban esencialmente la MISMA pantalla. Crea rutas/vistas realmente distintas, con componentes y acciones distintas.
2. Textos sobredimensionados, truncados o con errores de ortografía. UI compacta, jerarquía visual y contraste como en la referencia.
3. Fondos aleatorios de paisajes que tapaban contenido. Usa hero cinematográfico de calidad SOLO con derechos adecuados, con capa de contraste. Si faltan imágenes legales de series/películas, usa fondo neutral elegante; **nunca inventes contenido/catálogos personalizados**.
4. Tarjetas llamadas Netflix/YouTube/Prime/Clima que no hacían nada o mostraban datos ficticios. No simules acciones ni uses clima numérico inventado. Estado no disponible siempre explícito.
5. Versiones que congelaban la TV; evita CSS pesado, videos en bucle, fuentes gigantes, JS moderno no soportado, dependencias por CDN y descargas excesivas.

## Diseño objetivo (referencia visual)
- Estilo de sistema tvOS contemporáneo: barra superior fina con Inicio, Apps, Herramientas, Búsqueda y Ajustes; reloj, icono Wi-Fi y estado de red local al lado derecho.
- Hero panorámico de gran impacto visual (no más del ~50 % de altura útil), título legible, texto secundario breve y CTA contextual que sea real.
- Fila de apps de tamaño compacto, con logos verdaderos solo si se obtienen de recursos oficiales/permitidos y se optimizan localmente; tarjeta seleccionada con escala leve y borde/foco suave. Netflix/YouTube deben abrir apps nativas con ENTER. Prime Video debe mostrar estado «por probar» si no se ha validado.
- Segunda fila: herramientas funcionales, cada tarjeta con su propio dato útil REAL (hora actual, fecha, cronómetro, estado DIAL local) y acceso por ENTER.
- Vistas REALMENTE DIFERENTES:
  * Inicio: hero + apps favoritas + tarjetas informativas resumidas.
  * Apps: rejilla/catálogo de apps confirmadas, estado de cada integración, navegación horizontal y vertical con scroll/foco correcto.
  * Herramientas: panel de reloj a pantalla completa, temporizador de cuenta regresiva con iniciar/pausar/reiniciar, calendario mensual navegable, salvapantallas con reloj móvil, diagnóstico local de red.
  * Ajustes: márgenes/escala/posición visual guardables, IP de TV editable con validación IPv4, diagnóstico de accesos DIAL, restauración de preferencias de Alma TV (no restablecer Smart Hub).
  * Clima: solo datos reales de proveedor documentado (por ejemplo Open-Meteo) SI funciona en Orsay. Si no hay conexión HTTPS desde la TV, ofrecer un **puente local opcional** en la Mac, explicar que para datos actualizados la Mac tendría que seguir encendida, y mostrar «Sin datos» cuando no esté accesible. Preguntar ciudad al usuario; no asumirla.
  * Búsqueda: búsqueda REAL sobre apps, herramientas y contenido local ingresado por el usuario; no fingir acceso a catálogos privados ni historiales de streaming.
- Contenidos promocionales: solo material local autorizado por el usuario o material público con licencia correcta y atribución; no raspar datos privados ni simular «Continuar viendo Netflix» o recomendaciones personalizadas. No incrustar la captura de referencia como falso fondo de app.
- Foco animado sutil y rápido. Compatible con viejo WebKit: usar HTML/CSS/JS **ES5**, evitar React moderno, `const`, arrow functions, `fetch`, módulos, nuevas APIs, `backdrop-filter` requerido, CSS Grid sin fallback. No usar fuentes ilegibles ni dependencias de red para los iconos esenciales.

## Calidad y comprobaciones obligatorias
- Primero AUDITA el proyecto: arquitectura real, fallos de interacción, bugs de posicionamiento, formatos Orsay y limitaciones de su motor web. Comparación de la versión previa con el diseño objetivo y lista de mejoras verificables.
- Diseña un sistema de vistas (state machine/renderer), navegación por D-pad, foco, modal, retorno y pila de navegación. Que ARRIBA/ABAJO/IZQ/DER funcionen en cada pantalla y cada tarjeta; que RETURN retroceda y EXIT cierre de manera fiable.
- Prueba en un navegador local con simulación de resolución 1280×720 y screenshot; prueba escenarios de overscan 3 %, 5 %, 8 %, tamaños de texto y ausencia de red. Incluye teclas del control mapeadas a teclado para preview.
- Incluye tests de sintaxis JS (`node --check` si Node disponible), integridad del ZIP, `widget.info` texto plano, `config.xml`, cpname/widgetlist coincidentes, archivos y rutas relativos, y pruebas de navegación funcionales. No proclames funcionamiento real en la TV hasta que el usuario lo pruebe.
- Optimiza rendimiento: imágenes JPEG optimizadas y precargadas solo las necesarias; baja memoria, transiciones mínimas, ninguna descarga automática inútil. Documenta presupuesto de RAM/recursos y cómo medir problemas.
- Conserva **una versión de respaldo** instalable conocida antes de cada gran cambio. Cambia ID/versiones de forma coordinada y prevén caché de Smart Hub.
- El instalador debe funcionar con Python 3.8 en macOS, sin `sudo` salvo cuando sea realmente necesario para escuchar puerto 80. Mantén un comando de build reproducible y archivos correctos:
  `app/index.html`, `app/main.js`, `app/config.xml`, `app/widget.info`, `servidor/widgetlist.xml`, `servidor/Widget/<ZIP>`, `preparar.py`, `README.md`.
- **No root, no menú oculto de servicio, no flashear firmware, no deshabilitar aplicaciones del sistema, no borrar datos del Smart Hub, no puertos abiertos hacia internet.** La limpieza de sistema de CleanYourTV es Android-only y no se portará a Orsay; propón solo limpieza no destructiva con opciones oficiales Samsung y aprobación del usuario.

## Entregables y orden de trabajo
1. En una carpeta/proyecto independiente **AlmaTV-Orsay**, sin tocar otros repositorios/apps existentes, crea un README de arquitectura, matriz de compatibilidad e informe `LIMITACIONES.md`.
2. Implementa interfaz tvOS compacta y sus vistas de forma completamente navegable.
3. Integra Netflix/YouTube por DIAL sin confirmación doble; navegador por API Orsay; resto de apps con estado real comprobable, sin botones decorativos engañosos.
4. Implementa herramientas y calibración completas, con información real y degradación honesta.
5. Genera capturas de todas las pantallas y una comparación con referencia; muestra al usuario y corrige el diseño antes de sincronizar en la TV.
6. Empaqueta instalador Orsay validado y proporciona pasos simples de instalación por Wi-Fi y rollback. Solicita autorización antes de tocar nada en la TV; no ejecutes cambios automáticamente.

**No pares en una demo estática** ni anuncies «ya quedó» si no pasan las pruebas. Trabaja por hitos con resultados demostrables y reporta lo que de verdad es imposible por limitaciones de Orsay. Si tu entorno es Codex Cloud y no puede acceder a mi IP privada 192.168.1.249, NO simules una conexión: genera y prueba el software localmente y dame comandos para ejecutarlo con Codex en mi Mac y validarlo en la televisión.

Comienza abriendo y auditando todos los archivos adjuntos, inspeccionando CleanYourTV, y explícame en pocas líneas la arquitectura que vas a conservar y el plan de desarrollo. Después ejecuta el trabajo: no me pidas confirmar cada ajuste visual menor.
