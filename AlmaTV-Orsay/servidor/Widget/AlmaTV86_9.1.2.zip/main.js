/* Alma TV Orsay: ES5, no libraries, no remote assets. */
var Alma = (function () {
  "use strict";
  var A = {},
    api = null,
    rows = [],
    actions = {},
    stack = [],
    modal = null;
  var state = { view: "home", row: 0, col: 0 },
    defaults = {
      tvIp: "192.168.1.249",
      macIp: "192.168.1.30",
      bridge: false,
      relay: false,
      scale: 90,
      x: 0,
      y: 0,
      animations: true,
      seekStep: 10, appVolume: 70, appMuted: false,
      saverFrame: true,
      city: "Tuxtla Guti\u00e9rrez, Chiapas, M\u00e9xico",
      links: [],
      media: [],
      youtubeLinks: []
    };
  var prefs = {},
    interval = null,
    toastTimer = null,
    requests = [],
    generation = 0,
    pending = false,
    rendering = false,
    focusedNode = null,
    lastRenderedView = null,
    heroIndex = 0,
    sidebarIndex = 0,
    videoFull = false,
    youtubeFull = false,
    youtubeSelection = null,
    youtubeLoaded = "",
    macYoutubeLinks = [],
    macLinksBusy = false,
    macLinksLast = 0,
    macLinksHost = "",
    macLinksState = "Enlaces de la Mac: sin consultar.";
  var net = { YouTube: "Sin comprobar", Netflix: "Sin comprobar" },
    query = "",
    edit = null,
    cal = null;
  var month = new Date(),
    timer = {
      duration: 600000,
      left: 600000,
      end: 0,
      running: false,
      finished: false
    };
  var weather = {
    text: "Sin datos",
    detail: "Configura una ciudad y el puente local opcional.",
    icon: "cloud",
    observed: "",
    updated: 0
  };
  var apps = [
    {
      id: "netflix",
      name: "Netflix",
      detail: "Aplicaci\u00f3n del televisor",
      dial: "Netflix",
      mark: "N"
    },
    {
      id: "youtube",
      name: "YouTube",
      detail: "Aplicaci\u00f3n del televisor",
      dial: "YouTube",
      mark: "\u25b6"
    },
    {
      id: "prime",
      name: "Prime Video",
      detail: "Sin app nativa en tu TV",
      mark: "prime video"
    },
    {
      id: "disney",
      name: "Disney+",
      detail: "Sin soporte nativo en este modelo",
      mark: "Disney+"
    },
    {
      id: "apple",
      name: "Apple TV",
      detail: "Sin integraci\u00f3n nativa confirmada",
      mark: "tv"
    },
    {
      id: "max",
      name: "Max",
      detail: "Sin integraci\u00f3n nativa confirmada",
      mark: "max"
    },
    {
      id: "xbox",
      name: "Xbox",
      detail: "Consola conectada a HDMI 2",
      mark: "Xbox"
    },
    {
      id: "browser",
      name: "Navegador",
      detail: "Navegador original Samsung",
      mark: "\u25ce"
    },
    {
      id: "more",
      name: "M\u00e1s aplicaciones",
      detail: "Ver aplicaciones compatibles",
      mark: "\u25a6"
    }
  ];
  for (var brandIndex = 0; brandIndex < apps.length; brandIndex++) {
    if (
      /^(netflix|youtube|prime|disney|apple|max|xbox)$/.test(
        apps[brandIndex].id
      )
    )
      apps[brandIndex].logo = "assets/logos/" + apps[brandIndex].id + ".png";
  }
  var tools = [
    { id: "clock", name: "Reloj", detail: "Hora y fecha del dispositivo" },
    {
      id: "timer",
      name: "Temporizador",
      detail: "Iniciar, pausar y reiniciar"
    },
    { id: "calendar", name: "Calendario", detail: "Explorar meses" },
    { id: "saver", name: "Salvapantallas", detail: "Reloj en movimiento" },
    {
      id: "network",
      name: "Diagn\u00f3stico",
      detail: "Conexi\u00f3n de las aplicaciones"
    },
    { id: "weather", name: "Clima", detail: "Datos reales \u00b7 puente opcional" }
  ];
  function el(id) {
    return document.getElementById(id);
  }
  function htmlIfChanged(node, value) {
    if (node && node._almaHTML !== value) {
      node.innerHTML = value;
      node._almaHTML = value;
    }
  }
  function esc(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }
  function copy(o) {
    return JSON.parse(JSON.stringify(o));
  }
  function clamp(n, a, b) {
    return Math.max(a, Math.min(b, n));
  }
  function pad(n) {
    return ("0" + n).slice(-2);
  }
  function time() {
    var d = new Date();
    return pad(d.getHours()) + ":" + pad(d.getMinutes());
  }
  function date() {
    var d = new Date();
    return (
      [
        "domingo",
        "lunes",
        "martes",
        "mi\u00e9rcoles",
        "jueves",
        "viernes",
        "s\u00e1bado"
      ][d.getDay()] +
      ", " +
      d.getDate() +
      " de " +
      [
        "enero",
        "febrero",
        "marzo",
        "abril",
        "mayo",
        "junio",
        "julio",
        "agosto",
        "septiembre",
        "octubre",
        "noviembre",
        "diciembre"
      ][d.getMonth()]
    );
  }
  function ip(s) {
    var p = String(s).split("."),
      i;
    if (p.length !== 4) return false;
    for (i = 0; i < 4; i++) {
      if (!/^\d{1,3}$/.test(p[i]) || Number(p[i]) > 255) return false;
    }
    return true;
  }
  function privateIp(s) {
    if (!ip(s)) return false;
    var p = s.split(".");
    return (
      p[0] === "10" ||
      (p[0] === "192" && p[1] === "168") ||
      (p[0] === "172" && Number(p[1]) >= 16 && Number(p[1]) <= 31)
    );
  }
  function validUrl(s) {
    return /^https?:\/\/[^\s<>"']+$/i.test(s) && s.length < 1000;
  }
  function load() {
    prefs = copy(defaults);
    try {
      var p = JSON.parse(localStorage.getItem("alma.orsay.v7") || "null"),
        k;
      if (p) {
        for (k in defaults) {
          if (defaults.hasOwnProperty(k) && p.hasOwnProperty(k))
            prefs[k] = p[k];
        }
      }
    } catch (e) {}
    if (!privateIp(prefs.tvIp)) prefs.tvIp = defaults.tvIp;
    if (!privateIp(prefs.macIp)) prefs.macIp = defaults.macIp;
    prefs.scale = clamp(Number(prefs.scale) || 90, 76, 100);
    prefs.x = clamp(Number(prefs.x) || 0, -40, 40);
    prefs.y = clamp(Number(prefs.y) || 0, -30, 30);
    prefs.city = String(prefs.city || "").slice(0, 80);
    prefs.bridge = prefs.bridge === true;
    prefs.relay = prefs.relay === true;
    prefs.animations = prefs.animations !== false;
    prefs.seekStep = [5, 10, 30].indexOf(Number(prefs.seekStep)) !== -1 ? Number(prefs.seekStep) : 10;
    prefs.appVolume = isFinite(Number(prefs.appVolume)) ? clamp(Number(prefs.appVolume),0,100) : 70;
    prefs.appMuted = prefs.appMuted === true;
    prefs.saverFrame = prefs.saverFrame !== false;
    if (Object.prototype.toString.call(prefs.links) !== "[object Array]")
      prefs.links = [];
    prefs.links = prefs.links.slice(0, 12).filter(function (l) {
      return l && validUrl(l.url) && typeof l.name === "string";
    });
    if (Object.prototype.toString.call(prefs.media) !== "[object Array]")
      prefs.media = [];
    prefs.media = prefs.media.slice(0, 30).filter(function (t) {
      return (
        t &&
        typeof t.name === "string" &&
        validUrl(t.url) &&
        (t.kind === "audio" || t.kind === "video")
      );
    });
    if (Object.prototype.toString.call(prefs.youtubeLinks) !== "[object Array]") prefs.youtubeLinks = [];
    prefs.youtubeLinks = prefs.youtubeLinks.slice(0, 20).filter(function (item) {
      return item && (item.provider === "dailymotion" ? /^[A-Za-z0-9]{5,12}$/ : /^[A-Za-z0-9_-]{11}$/).test(item.id) && typeof item.name === "string";
    });
  }
  function mediaTracks() {
    return [
      {
        name: "Prueba de sonido \u00b7 composici\u00f3n original",
        url: "assets/media/prueba-sonido.mp3",
        kind: "audio"
      }
    ].concat(prefs.media || []);
  }
  function save() {
    try {
      localStorage.setItem("alma.orsay.v7", JSON.stringify(prefs));
      return true;
    } catch (e) {
      notice(
        "No se pudieron guardar los ajustes. Revisa el espacio disponible."
      );
      return false;
    }
  }
  function apply() {
    var v =
      "translate(" +
      prefs.x +
      "px," +
      prefs.y +
      "px) scale(" +
      prefs.scale / 100 +
      ")";
    el("safe").style.webkitTransform = v;
    el("safe").style.transform = v;
    el("safe").className = prefs.animations ? "" : "reduced";
    fitScreen();
  }
  function fitScreen() {
    var width =
      window.innerWidth || document.documentElement.clientWidth || 1280;
    var height =
      window.innerHeight || document.documentElement.clientHeight || 720;
    var transform = "scale(" + width / 1280 + "," + height / 720 + ")";
    el("stage").style.webkitTransform = transform;
    el("stage").style.transform = transform;
    if (youtubeLoaded) updateYoutube();
  }
  function syncBackgrounds() {
    var saver = state.view === "saver",
      media =
        typeof AlmaMedia !== "undefined" &&
        /^assets\/salvapantallas\.(jpg|png)$/.test(AlmaMedia.saver);
    el("stage").setAttribute("data-view", state.view);
    el("stage").setAttribute(
      "data-saver-frame",
      prefs.saverFrame ? "true" : "false"
    );
    el("wallpaper").style.display = state.view === "home" ? "block" : "none";
    el("wallpaper-shade").style.display =
      state.view === "home" ? "block" : "none";
    el("saver-wallpaper").style.display =
      saver && !prefs.saverFrame ? "block" : "none";
    if (media) {
      el("wallpaper").style.backgroundImage = "url(" + AlmaMedia.saver + ")";
      el("saver-wallpaper").style.backgroundImage =
        "url(" + AlmaMedia.saver + ")";
    }
  }
  var confirmSequence = 0;
  function confirmAction(fn) {
    var node = el(focusedId());
    if (node) {
      node.className = node.className.replace(/\s*press-[ab]\b/g, "");
      node.className += " press-" + (confirmSequence++ % 2 ? "a" : "b");
    }
    fn();
  }
  function notice(s) {
    el("toast").innerHTML = esc(s);
    el("toast").style.display = "block";
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      el("toast").style.display = "none";
    }, 4500);
  }
  function button(id, title, small, fn, cls) {
    actions[id] = fn;
    var icons = { "tv-volume": "media", "seek-step": "media", calibrate: "hub", "tv-ip": "hub", "mac-ip": "network", bridge: "network", relay: "apps", motion: "media", "saver-frame": "saver", location: "weather", links: "browser", diagnostic: "network", reset: "settings" };
    var match = /^tool-(\d+)$/.exec(id);
    var icon = match && tools[Number(match[1])] ? tools[Number(match[1])].id : icons[id];
    return (
      '<button type="button" id="' +
      id +
      '" class="' +
      (cls || "card") +
      '" data-focus="' +
      id +
      '">' +
      (icon ? '<span aria-hidden="true" class="card-icon nav-icon icon-' + icon + '"></span>' : "") +
      '<strong>' + esc(title) +
      "</strong>" +
      (small ? "<small>" + esc(small) + "</small>" : "") +
      "</button>"
    );
  }
  function pill(id, label, fn) {
    actions[id] = fn;
    return (
      '<button type="button" id="' +
      id +
      '" class="pill" data-focus="' +
      id +
      '">' +
      esc(label) +
      "</button>"
    );
  }
  function row(ids) {
    rows.push(ids);
  }
  function head(label, title, desc) {
    return (
      '<div class="page-head"><div class="eyebrow">' +
      esc(label) +
      "</div><h1>" +
      esc(title) +
      "</h1><p>" +
      esc(desc) +
      "</p></div>"
    );
  }
  var navViews = [
    "home",
    "search",
    "apps",
    "media",
    "hub",
    "clock",
    "weather",
    "calendar",
    "timer",
    "settings"
  ];
  function nav() {
    var names = [
        "Inicio",
        "Buscar",
        "Aplicaciones",
        "Multimedia",
        "Smart Hub",
        "Reloj",
        "Clima",
        "Calendario",
        "Temporizador",
        "Ajustes"
      ],
      icons = [
        "home",
        "search",
        "apps",
        "media",
        "hub",
        "clock",
        "weather",
        "calendar",
        "timer",
        "settings"
      ],
      h = "",
      ids = [];
    for (var i = 0; i < names.length; i++) {
      (function (i) {
        var id = "nav-" + i;
        ids.push(id);
        actions[id] = function () {
          sidebarIndex = i;
          if (navViews[i] === "hub") {
            exit();
            return;
          }
          go(navViews[i]);
        };
        h +=
          '<button id="' +
          id +
          '" data-focus="' +
          id +
          '" class="nav' +
          (state.view === navViews[i] ? " active" : "") +
          '"><span class="nav-icon icon-' +
          icons[i] +
          '"></span>' +
          names[i] +
          "</button>";
      })(i);
    }
    el("nav").innerHTML = h;
    row(ids);
  }
  function appCard(a, i, large) {
    var id = "app-" + i;
    actions[id] = function () {
      launch(a);
    };
    var detail =
      a.dial && net[a.dial] !== "Sin comprobar" ? net[a.dial] : a.detail;
    return (
      '<button type="button" id="' +
      id +
      '" data-focus="' +
      id +
      '" class="card app ' +
      a.id +
      '">' +
      (/^(prime|disney|apple|max)$/.test(a.id)
        ? '<span class="app-note">' +
          (/^(prime|disney)$/.test(a.id) ? "No compatible" : "Sin comprobar") +
          "</span>"
        : a.id === "xbox"
          ? '<span class="app-note">HDMI 2</span>'
          : "") +
      '<span class="app-mark">' +
      (a.logo
        ? '<img class="brand-logo" src="' + a.logo + '" alt="">'
        : '<span aria-hidden="true" class="app-symbol nav-icon icon-' + (a.id === "browser" ? "browser" : "apps") + '"></span>') +
      "</span><strong>" +
      esc(a.name) +
      "</strong><small>" +
      esc(detail) +
      "</small></button>"
    );
  }
  function updateHero(index) {
    heroIndex = index;
    var messages = [
        [
          "NETFLIX",
          "Ve WWE Raw on Netflix",
          "Disfruta de WWE Raw desde la aplicaci\u00f3n de Netflix.",
          "Abrir Netflix"
        ],
        [
          "YOUTUBE",
          "\u00a1Bienvenido, IWC!",
          "Contin\u00faa viendo tus videos favoritos.",
          "Abrir YouTube"
        ],
        [
          "PRIME VIDEO",
          "La \u00daltima Palabra",
          "Disfr\u00fatalo solo por Fox con tu suscripci\u00f3n.",
          "Ver opciones de Prime Video"
        ],
        [
          "DISNEY+",
          "Un mundo de historias",
          "Descubre aventuras, personajes y mundos en Disney+.",
          "Ver opciones de Disney+"
        ],
        [
          "APPLE TV",
          "Historias que te acompa\u00f1an",
          "Consulta las opciones de Apple TV en un dispositivo compatible.",
          "Ver opciones de Apple TV"
        ],
        [
          "MAX",
          "Grandes historias, a tu manera",
          "Descubre las opciones de Max en un dispositivo compatible.",
          "Ver opciones de Max"
        ],
        [
          "XBOX \u00b7 HDMI 2",
          "Tu pr\u00f3xima partida empieza aqu\u00ed",
          "Enciende tu consola y elige tu pr\u00f3xima aventura.",
          "Cambiar a HDMI 2"
        ],
        [
          "NAVEGADOR",
          "Tus sitios favoritos, m\u00e1s cerca",
          "Abre el navegador del televisor.",
          "Abrir el navegador"
        ],
        [
          "APLICACIONES",
          "M\u00e1s formas de disfrutar",
          "Revisa los accesos y la compatibilidad de tus aplicaciones.",
          "Ver aplicaciones"
        ]
      ],
      message = messages[index] || messages[0];
    htmlIfChanged(el("hero-label"), esc(message[0]));
    htmlIfChanged(el("hero-title"), esc(message[1]));
    htmlIfChanged(el("hero-copy"), esc(message[2]));
    htmlIfChanged(el("hero-cta"), esc(message[3]));
    actions["hero-cta"] = function () {
      launch(apps[heroIndex]);
    };
  }
  function home() {
    var h =
      '<section class="hero"><div class="eyebrow" id="hero-label"></div><h1 id="hero-title"></h1><p id="hero-copy"></p>' +
      pill("hero-cta", "Abrir Netflix", function () {
        launch(apps[heroIndex]);
      }) +
      '<span class="hero-credit">Mensajes personalizados \u00b7 disponibilidad seg\u00fan el servicio</span></section>';
    row(["hero-cta"]);
    h +=
      '<section class="home-apps"><h2 class="section-title">Aplicaciones <span>Pulsa Aceptar para abrir</span></h2><div class="app-carousel"><div class="row app-track">';
    var ids = [],
      i;
    for (i = 0; i < apps.length; i++) {
      h += appCard(apps[i], i);
      ids.push("app-" + i);
    }
    row(ids);
    h += '</div></div></section><section class="home-now"><h2 class="section-title">En reproducci\u00f3n</h2><div id="home-player" class="home-player" tabindex="0" role="region" aria-label="En reproducci\u00f3n"><div class="home-audio"><span class="media-eq"><b></b><b></b><b></b></span><h3 id="home-media-title"></h3><p id="home-media-state"></p></div></div></section><section class="home-tools"><h2 class="section-title">Herramientas</h2><div class="row">';
    actions["home-player"] = function () { go(youtubeLoaded ? "youtube" : (AlmaPlayer.snapshot().index >= 0 ? "media" : "youtube-list")); };
    row(["home-player"]);
    h = h.replace('</section><section class="home-tools">', '<div class="home-youtube-actions">' + pill("home-youtube", "Elegir video de YouTube", function () { go("youtube-list"); }) + '</div></section><section class="home-tools">');
    row(["home-youtube"]);
    ids = [];
    var order = [0, 5, 2, 4, 1, 3],
      symbols = ["\u25f7", "\u25f4", "\u25a4", "\u25a7", "\u2301", "\u2601"];
    for (i = 0; i < order.length; i++) {
      (function (index) {
        var t = tools[index],
          v = [
            time(),
            timerText(),
            date().split(",")[0],
            "Abrir",
            net.YouTube.indexOf("Disponible") === 0
              ? "Televisor conectado"
              : "Sin comprobar",
            weather.text
          ][index];
        h += button(
          "tool-" + index,
          t.name,
          v,
          function () {
            go(t.id);
          },
          "card tool tool-" + t.id
        );
        ids.push("tool-" + index);
      })(order[i]);
    }
    row(ids);
    return h + "</div></section>";
  }
  function catalog(kind) {
    var list = kind === "apps" ? apps : tools,
      h =
        head(
          kind === "apps" ? "ENTRETENIMIENTO" : "A TU RITMO",
          kind === "apps" ? "Tus aplicaciones" : "Herramientas",
          kind === "apps"
            ? "Elige una aplicaci\u00f3n. Algunos servicios requieren un dispositivo compatible."
            : "Funciones locales, sin cuentas ni cat\u00e1logos simulados."
        ) + '<div class="grid">',
      ids = [],
      i;
    for (i = 0; i < list.length; i++) {
      (function (i) {
        var t = list[i];
        h +=
          kind === "apps"
            ? appCard(t, i, true)
            : button("tool-" + i, t.name, t.detail, function () {
                go(t.id);
              });
        ids.push((kind === "apps" ? "app-" : "tool-") + i);
      })(i);
      if (ids.length === 3) {
        row(ids);
        ids = [];
      }
    }
    if (ids.length) row(ids);
    return h + "</div>";
  }
  function settings() {
    var items = [
      [
        "calibrate",
        "Pantalla",
        "Zona segura, escala y posici\u00f3n",
        function () {
          cal = copy(prefs);
          go("calibrate");
        }
      ],
      [
        "tv-ip",
        "IP del televisor",
        prefs.tvIp,
        function () {
          editor("tvIp", "Direcci\u00f3n IP del televisor", prefs.tvIp, "ip");
        }
      ],
      [
        "mac-ip",
        "IP de la Mac",
        prefs.macIp,
        function () {
          editor("macIp", "Direcci\u00f3n IP de la Mac", prefs.macIp, "ip");
        }
      ],
      [
        "bridge",
        "Puente local",
        prefs.bridge ? "Activado \u00b7 puerto 8088" : "Desactivado \u00b7 opcional",
        function () {
          prefs.bridge = !prefs.bridge;
          weather = {
            text: "Sin datos",
            detail: "Actualiza para consultar el puente configurado."
          };
          save();
          invalidate();
          render();
        }
      ],
      [
        "relay",
        "Conexi\u00f3n de aplicaciones",
        prefs.relay
          ? "Mac \u00b7 requiere permitir lanzamientos"
          : "Directo desde la TV",
        function () {
          prefs.relay = !prefs.relay;
          save();
          invalidate();
          render();
        }
      ],
      [
        "motion",
        "Animaciones",
        prefs.animations ? "Activadas" : "Reducidas",
        function () {
          prefs.animations = !prefs.animations;
          save();
          apply();
          render();
        }
      ],
      ["pair-phone", "Conectar celular", "Control, m\u00fasica, fotos y cola por QR", function () { go("pair-phone"); }],
      ["tv-volume", "Volumen del control remoto", AlmaTVAudio.active() ? "Control nativo activo \u00b7 pulsa para desactivar" : "Activar control nativo de la TV", toggleTVVolume],
      ["seek-step", "Avanzar y retroceder", prefs.seekStep + " segundos \u00b7 elegir 5, 10 o 30", cycleSeekStep],
      [
        "saver-frame",
        "Marco del salvapantallas",
        prefs.saverFrame
          ? "Blanco \u00b7 solo en el salvapantallas"
          : "Sin marco \u00b7 imagen a pantalla completa",
        function () {
          prefs.saverFrame = !prefs.saverFrame;
          save();
          render();
        }
      ],
      [
        "location",
        "Ciudad del clima",
        prefs.city || "Sin configurar",
        function () {
          editor("city", "Ciudad y pa\u00eds", prefs.city, "text");
        }
      ],
      [
        "links",
        "Mis enlaces",
        prefs.links.length + " guardados \u00b7 b\u00fasqueda local",
        function () {
          go("links");
        }
      ],
      [
        "diagnostic",
        "Comprobar conexi\u00f3n",
        "Comprobar Netflix y YouTube",
        function () {
          go("network");
        }
      ],
      [
        "reset",
        "Restaurar Alma TV",
        "Solo preferencias de esta aplicaci\u00f3n",
        reset
      ]
    ];
    var h =
        head(
          "PREFERENCIAS",
          "A tu medida",
          "Los ajustes no cambian Smart Hub, las aplicaciones de Samsung ni el firmware."
        ) + '<div class="grid settings">',
      ids = [];
    for (var i = 0; i < items.length; i++) {
      h += button(items[i][0], items[i][1], items[i][2], items[i][3]);
      ids.push(items[i][0]);
      if (ids.length === 3) {
        row(ids);
        ids = [];
      }
    }
    if (ids.length) row(ids);
    return h + "</div>";
  }
  function timerLeft() {
    return timer.running
      ? Math.max(0, timer.end - new Date().getTime())
      : timer.left;
  }
  function timerText() {
    var sec = Math.ceil(timerLeft() / 1000);
    return pad(Math.floor(sec / 60)) + ":" + pad(sec % 60);
  }
  function toggleTimer() {
    if (timer.running) {
      timer.left = timerLeft();
      timer.running = false;
    } else {
      if (timer.left <= 0) timer.left = timer.duration;
      timer.end = new Date().getTime() + timer.left;
      timer.running = true;
      timer.finished = false;
    }
    render();
  }
  function resetTimer() {
    timer.running = false;
    timer.left = timer.duration;
    timer.finished = false;
    render();
  }
  function adjustTimer(d) {
    timer.running = false;
    timer.duration = clamp(timer.duration + d * 60000, 60000, 120 * 60000);
    timer.left = timer.duration;
    timer.finished = false;
    render();
  }
  function timerView() {
    var h =
      head(
        "TIEMPO PARA TI",
        "Temporizador",
        "Contin\u00faa mientras navegas en Alma TV. No contin\u00faa si sales de la aplicaci\u00f3n."
      ) +
      '<div class="panel"><div class="countdown" id="countdown">' +
      timerText() +
      '</div><div class="muted" id="timer-state">' +
      (timer.running
        ? "En marcha"
        : timer.finished
          ? "Tiempo terminado"
          : "En pausa") +
      '</div><div class="actions">' +
      pill("minus", "\u2212 1 minuto", function () {
        adjustTimer(-1);
      }) +
      pill("start", timer.running ? "Pausar" : "Iniciar", toggleTimer) +
      pill("plus", "+ 1 minuto", function () {
        adjustTimer(1);
      }) +
      pill("reset-timer", "Reiniciar", resetTimer) +
      "</div></div>";
    row(["minus", "start", "plus", "reset-timer"]);
    return h;
  }
  function calendarView() {
    var y = month.getFullYear(),
      m = month.getMonth(),
      start = (new Date(y, m, 1).getDay() + 6) % 7,
      days = new Date(y, m + 1, 0).getDate(),
      now = new Date(),
      names = [
        "enero",
        "febrero",
        "marzo",
        "abril",
        "mayo",
        "junio",
        "julio",
        "agosto",
        "septiembre",
        "octubre",
        "noviembre",
        "diciembre"
      ];
    var h =
      head(
        "CALENDARIO",
        names[m] + " " + y,
        "Explora los meses con los controles inferiores."
      ) + '<div class="panel"><table class="calendar"><thead><tr>';
    var week = ["Lun", "Mar", "Mi\u00e9", "Jue", "Vie", "S\u00e1b", "Dom"],
      i;
    for (i = 0; i < 7; i++) h += "<th>" + week[i] + "</th>";
    h += "</tr></thead><tbody>";
    for (i = 0; i < 42; i++) {
      if (i % 7 === 0) h += "<tr>";
      var n = i - start + 1;
      h +=
        "<td" +
        (n === now.getDate() && m === now.getMonth() && y === now.getFullYear()
          ? ' class="today"'
          : "") +
        ">" +
        (n > 0 && n <= days ? n : "") +
        "</td>";
      if (i % 7 === 6) h += "</tr>";
    }
    h +=
      '</tbody></table><div class="actions">' +
      pill("prev-month", "\u2190 Mes anterior", function () {
        month = new Date(y, m - 1, 1);
        render();
      }) +
      pill("today", "Hoy", function () {
        month = new Date();
        render();
      }) +
      pill("next-month", "Mes siguiente \u2192", function () {
        month = new Date(y, m + 1, 1);
        render();
      }) +
      "</div></div>";
    row(["prev-month", "today", "next-month"]);
    return h;
  }
  function networkView() {
    var h =
      head(
        "DIAGN\u00d3STICO LOCAL",
        "Conexi\u00f3n con tu TV",
        "El estado DIAL no demuestra acceso a internet ni conexi\u00f3n Wi-Fi del sistema."
      ) +
      '<div class="panel"><div class="diagnostic">TV: ' +
      esc(prefs.tvIp) +
      ' \u00b7 puerto 8080<br>YouTube: <span id="dial-youtube">' +
      esc(net.YouTube) +
      '</span><br>Netflix: <span id="dial-netflix">' +
      esc(net.Netflix) +
      "</span><br>Ruta: " +
      (prefs.relay
        ? "puente Mac " + esc(prefs.macIp) + ":8088"
        : "directa desde la aplicaci\u00f3n") +
      '</div><p class="muted">HTTP 0 puede indicar CORS, red bloqueada o TV inaccesible. No se interpreta como falta de internet.</p><div class="actions">' +
      pill("check-network", "Comprobar ahora", checkNetwork) +
      pill("edit-tv", "Cambiar IP de TV", function () {
        editor("tvIp", "Direcci\u00f3n IP del televisor", prefs.tvIp, "ip");
      }) +
      "</div></div>";
    row(["check-network", "edit-tv"]);
    return h;
  }
  function calibration() {
    var h =
      '<div class="calibration">' +
      head(
        "PANTALLA",
        "Encuentra tus bordes",
        "Este marco, los modales y todas las vistas comparten la misma transformaci\u00f3n."
      ) +
      '<p class="muted">Arriba/abajo: elegir ajuste \u00b7 Izq/der: cambiar \u00b7 Aceptar: presets.<br>Verde: guardar \u00b7 Volver: cancelar \u00b7 Amarillo: ajustes</p><button class="pill" id="cal-adjust" data-focus="cal-adjust"><span class="cal-value" id="cal-value"></span></button><p class="help">Escala entre 76\u2013100 %. 90 % inicial protege del overscan.<br>Los presets reservan 3 %, 5 % u 8 % por cada borde.</p>' +
      pill("safe3", "3 %", function () {
        prefs.scale = 94;
        apply();
        updateCal();
      }) +
      " " +
      pill("safe5", "5 %", function () {
        prefs.scale = 90;
        apply();
        updateCal();
      }) +
      " " +
      pill("safe8", "8 %", function () {
        prefs.scale = 84;
        apply();
        updateCal();
      }) +
      " " +
      pill("save-cal", "Guardar", saveCalibration) +
      "</div>";
    row(["cal-adjust"]);
    row(["safe3", "safe5", "safe8", "save-cal"]);
    return h;
  }
  var calAxis = 0;
  function updateCal() {
    if (el("cal-value"))
      el("cal-value").innerHTML = [
        "Escala: " + prefs.scale + " %",
        "Posici\u00f3n X: " + prefs.x + " px",
        "Posici\u00f3n Y: " + prefs.y + " px"
      ][calAxis];
  }
  function saveCalibration() {
    if (save()) {
      cal = null;
      back();
      notice("Calibraci\u00f3n guardada");
    }
  }
  function weatherView() {
    var h =
      head(
        "CLIMA",
        prefs.city || "Tu ciudad",
        "Open-Meteo \u00b7 datos reales a trav\u00e9s del puente opcional en tu Mac."
      ) +
      '<div class="panel"><h2 id="weather-value">' +
      esc(weather.text) +
      '</h2><p id="weather-detail" class="muted">' +
      esc(weather.detail) +
      '</p><p class="muted">La Mac debe permanecer encendida. No se consulta tu ubicaci\u00f3n autom\u00e1ticamente.</p><div class="actions">' +
      pill("refresh-weather", "Actualizar", getWeather) +
      pill("city-weather", "Configurar ciudad", function () {
        editor("city", "Ciudad y pa\u00eds", prefs.city, "text");
      }) +
      "</div></div>";
    row(["refresh-weather", "city-weather"]);
    return h;
  }
  function allEntries() {
    var l = [],
      i;
    for (i = 0; i < apps.length; i++)
      (function (a) {
        l.push({
          name: a.name,
          type: "Aplicaci\u00f3n",
          open: function () {
            launch(a);
          }
        });
      })(apps[i]);
    for (i = 0; i < tools.length; i++)
      (function (t) {
        l.push({
          name: t.name,
          type: "Herramienta",
          open: function () {
            go(t.id);
          }
        });
      })(tools[i]);
    for (i = 0; i < prefs.links.length; i++)
      (function (link) {
        l.push({
          name: link.name,
          type: "Enlace personal",
          open: function () {
            browser(link.url);
          }
        });
      })(prefs.links[i]);
    l.push({
      name: "Reproductor multimedia",
      type: "M\u00fasica y videos",
      open: function () {
        go("media");
      }
    });
    return l;
  }
  function normalize(s) {
    var from = "\u00e1\u00e9\u00ed\u00f3\u00fa\u00fc\u00f1",
      to = "aeiouun",
      t = String(s).toLowerCase(),
      i;
    for (i = 0; i < from.length; i++)
      t = t.split(from.charAt(i)).join(to.charAt(i));
    return t;
  }
  function search() {
    var h =
      head(
        "SOLO LO TUYO",
        "Encuentra tu pr\u00f3ximo paso",
        "Busca aplicaciones, herramientas y enlaces guardados."
      ) +
      '<div class="search-layout">' +
      pill("search-edit", query || "Escribir b\u00fasqueda\u2026", function () {
        editor("query", "Buscar en Alma TV", query, "text");
      });
    row(["search-edit"]);
    h += '<div class="results">';
    var entries = allEntries(),
      ids = [],
      n = 0;
    for (var i = 0; i < entries.length; i++) {
      if (
        !query ||
        normalize(entries[i].name).indexOf(normalize(query)) !== -1
      ) {
        (function (e, n) {
          h += button("result-" + n, e.name, e.type, e.open);
          ids.push("result-" + n);
        })(entries[i], n++);
        if (ids.length === 4) {
          row(ids);
          ids = [];
        }
      }
    }
    if (ids.length) row(ids);
    if (!n)
      h += '<div class="empty">Sin resultados para \u00ab' + esc(query) + "\u00bb.</div>";
    return h + "</div></div>";
  }
  function linksView() {
    var h =
      head(
        "CONTENIDO LOCAL",
        "Mis enlaces",
        "Hasta 12 enlaces propios. Se abren en el navegador Samsung, cuya compatibilidad puede ser limitada."
      ) +
      pill("add-link", "A\u00f1adir enlace", function () {
        if (prefs.links.length >= 12) {
          notice("L\u00edmite de 12 enlaces");
          return;
        }
        editor("linkName", "Nombre del enlace", "", "text");
      });
    row(["add-link"]);
    h += '<div class="grid results">';
    for (var i = 0; i < prefs.links.length; i++) {
      (function (i) {
        h += button(
          "link-" + i,
          prefs.links[i].name,
          "Abrir enlace",
          function () {
            browser(prefs.links[i].url);
          }
        );
        h += pill("remove-" + i, "Eliminar", function () {
          prefs.links.splice(i, 1);
          save();
          render();
        });
        row(["link-" + i, "remove-" + i]);
      })(i);
    }
    return h + "</div>";
  }
  function youtubeFullscreen(enabled) {
    if (enabled) youtubeAudioOnly = false;
    youtubeFull = enabled;
    var host = el("youtube-host");
    host.className = enabled ? "youtube-full" : "";
    host.style.clip = "";
    host.style.left = ""; host.style.top = "";
    host.style.width = ""; host.style.height = "";
    updateYoutube();
  }
  function closeYoutube() {
    AlmaYouTube.close();
    youtubeLoaded = "";
    hubAutoplay = false;
    el("safe").setAttribute("data-youtube", "none");
    if (youtubeFull) youtubeFullscreen(false);
  }
  var youtubeAudioOnly = false, livePending = null, liveBusy = false, liveNext = 0, liveFailures = 0;
  function liveAck(command, status) {
    request("POST", "http://" + prefs.macIp + ":8088/youtube/live/ack", function () {}, {id: command.id, status: status});
  }
  function pollLive() {
    var now = new Date().getTime();
    if (liveBusy || now < liveNext || document.hidden || modal || edit || state.view === "calibrate") return;
    liveBusy = true; liveNext = now + 2000;
    var mac = prefs.macIp, epoch = generation;
    request("GET", "http://" + mac + ":8088/youtube/live", function (code, body) {
      liveBusy = false;
      if (epoch !== generation || mac !== prefs.macIp) return;
      if (code !== 200) { liveFailures++; liveNext = new Date().getTime() + Math.min(30000, 5000 * liveFailures); return; }
      liveFailures = 0;
      try {
        var data = JSON.parse(body), command = data.command;
        if (data.status !== "waiting" || !command || !/^[a-f0-9]{32}$/.test(command.id) || !(command.provider === "dailymotion" ? /^[A-Za-z0-9]{5,12}$/ : /^[A-Za-z0-9_-]{11}$/).test(command.video) || (command.mode !== "audio" && command.mode !== "video")) return;
        var storage = "alma.live.last." + mac;
        if (livePending && livePending.id === command.id) return;
        try { if (localStorage.getItem(storage) === command.id) return; localStorage.setItem(storage, command.id); } catch (ignore) {}
        livePending = {id: command.id, sent: false, confirmed: false};
        openYoutube({id: command.video, provider:command.provider, name: typeof command.name === "string" ? command.name.slice(0,80) : "YouTube en tiempo real"}, command.mode === "audio",true);
        go("home");
        liveAck(livePending, "received");
      } catch (error) {}
    });
  }
  var youtubeLayoutKey = "";
  function cycleSeekStep() {
    var values = [5, 10, 30];
    prefs.seekStep = values[(values.indexOf(prefs.seekStep) + 1) % values.length];
    save(); render();
  }
  function hideYoutubeImage(host) {
    AlmaYouTube.present(false, youtubeAudioOnly || state.view === "saver");
    if (host.style.left !== "-10000px") {
      host.style.left = "-10000px"; host.style.top = "-10000px";
      host.style.clip = "rect(0px,0px,0px,0px)";
      host.style.visibility = "hidden";
    }
    host.style.display = youtubeAudioOnly || state.view === "saver" ? "none" : "block";
    youtubeLayoutKey = "";
    el("safe").setAttribute("data-youtube", "hidden");
  }
  function updateYoutube() {
    var value = AlmaYouTube.snapshot(), host = el("youtube-host");
    el("safe").setAttribute("data-youtube-mode", youtubeAudioOnly ? "audio" : "video");
    if (hubAutoplay && value.ready) {hubAutoplay=false;if(value.state!==1)AlmaYouTube.send("play");}
    if (livePending && !livePending.confirmed) {
      if (value.state === 1) { livePending.confirmed = true; liveAck(livePending, "playing"); }
      else if (value.failed) { livePending.confirmed = true; liveAck(livePending, /ACTIVACION/.test(value.status) ? "blocked" : "error"); }
      else if (value.ready && !livePending.sent) { livePending.sent = true; AlmaYouTube.send("play"); }
    }
    if (youtubeAudioOnly) {
      htmlIfChanged(el("home-media-title"), esc(value.title || (youtubeSelection && youtubeSelection.name) || "YouTube"));
      htmlIfChanged(el("home-media-state"), "Solo audio \u00b7 " + esc(value.status));
    }
    var slot = el(state.view === "home" ? "home-player" : "youtube-slot");
    htmlIfChanged(el("youtube-state"), esc(value.status));
    if (value.title) htmlIfChanged(el("youtube-title"), esc(value.title));
    if (!youtubeLoaded) return;
    // Navigation changes presentation only; never send pause/play or reload.
    if (youtubeAudioOnly || state.view === "saver" || modal || (!youtubeFull && !slot)) {
      hideYoutubeImage(host);
      return;
    }
    host.style.display = "block";
    var screenWidth = window.innerWidth || document.documentElement.clientWidth || 1280;
    var screenHeight = window.innerHeight || document.documentElement.clientHeight || 720;
    var width = screenWidth, height = screenHeight, left = 0, top = 0;
    var clipTop = 0, clipBottom = height;
    var layoutKey = [state.view, youtubeFull, screenWidth, screenHeight, el("view").scrollTop, prefs.scale, prefs.x, prefs.y].join(":");
    if (layoutKey === youtubeLayoutKey) { AlmaYouTube.present(true); AlmaYouTube.resize(parseFloat(host.style.width), parseFloat(host.style.height)); return; }
    if (!youtubeFull) {
      var slotHeight = slot.offsetWidth * 9 / 16 + "px";
      if (slot.style.height !== slotHeight) slot.style.height = slotHeight;
      var box = slot.getBoundingClientRect(), viewport = el("view").getBoundingClientRect();
      width = box.width; height = width * 9 / 16; left = box.left; top = box.top;
      clipTop = Math.max(0, viewport.top - top, -top);
      clipBottom = Math.min(height, viewport.bottom - top, screenHeight - top);
    }
    if (!isFinite(width) || !isFinite(height) || !isFinite(left) || !isFinite(top) || width <= 0 || height <= 0 || left < 0 || left + width > screenWidth + 2 || clipBottom <= clipTop) {
      hideYoutubeImage(host);
      return;
    }
    var geometry = { left: Math.round(left) + "px", top: Math.round(top) + "px", width: Math.round(width) + "px", height: Math.round(height) + "px" };
    for (var property in geometry) if (Object.prototype.hasOwnProperty.call(geometry, property) && host.style[property] !== geometry[property]) host.style[property] = geometry[property];
    host.style.clip = "rect(" + Math.ceil(clipTop) + "px," + Math.round(width) + "px," + Math.floor(clipBottom) + "px,0px)";
    host.style.visibility = "visible";
    youtubeLayoutKey = layoutKey;
    AlmaYouTube.present(true);
    el("safe").setAttribute("data-youtube", "large");
    AlmaYouTube.resize(width, height);
  }
  function youtubeList() {
    var h = head("TUS ENLACES", "Videos de YouTube", "Guarda enlaces desde la Mac. Selecciona un video y pulsa Reproducir.");
    h += pill("youtube-list-refresh", "Actualizar enlaces de la Mac", function () { loadMacYoutube(false); }) +
      pill("youtube-list-add", "Pegar enlace", function () { editor("youtubeUrl", "Pega un enlace de YouTube", "", "text"); });
    row(["youtube-list-refresh", "youtube-list-add"]);
    h += '<p id="mac-links-state">' + esc(macLinksState) + '</p><div class="youtube-saved">';
    var items = macYoutubeLinks.concat(prefs.youtubeLinks);
    for (var i = 0; i < items.length; i++) {
      (function (item, index) {
        h += button("youtube-saved-" + index, item.name, "Abrir en el reproductor", function () { openYoutube(item); }, "card media-item") + "<br>";
        row(["youtube-saved-" + index]);
      })(items[i], i);
    }
    if (!items.length) h += '<p>A\u00f1ade tus enlaces en http://' + esc(prefs.macIp) + ':8088/enlaces o usa Pegar enlace.</p>';
    return h + "</div>";
  }
  function openYoutube(item, audioOnly, autoplay) {
    youtubeAudioOnly = audioOnly === true;
    if (typeof audioOnly === "undefined") livePending = null;
    youtubeSelection = item;
    youtubeSelection.remoteAutoplay=autoplay===true;
    if(AlmaYouTube.reusable(prefs.macIp,item.provider)){youtubeLoaded="";hubAutoplay=false;}
    else closeYoutube();
    AlmaPlayer.pause();
    go("youtube");
  }
  function saveYoutube(url, name) {
    var parsed = AlmaYouTube.parseLink(url), id = parsed && parsed.id;
    if (!id) { notice("Usa un enlace individual de YouTube o Dailymotion. Para archivos, usa un enlace directo MP3 o MP4."); return false; }
    if (prefs.youtubeLinks.length >= 20) { notice("Puedes guardar hasta 20 enlaces."); return false; }
    prefs.youtubeLinks.push({ id: id, provider:parsed.provider, name: name || (parsed.provider === "dailymotion" ? "Dailymotion" : "YouTube") + " \u00b7 " + id });
    save();
    return true;
  }
  function youtubeView() {
    var h = head((youtubeSelection && youtubeSelection.provider === "dailymotion" ? "DAILYMOTION" : "YOUTUBE") + " INTEGRADO", youtubeSelection ? youtubeSelection.name : "YouTube", "Reproductor oficial \u00b7 requiere el puente actualizado e internet en la TV.");
    h = h.replace("<h1>", '<h1 id="youtube-title">');
    h += '<div id="youtube-slot" tabindex="0" role="region" aria-label="V\u00eddeo: Aceptar reproduce o pausa"></div><p id="youtube-state" class="youtube-state"></p><div class="youtube-controls">';
    actions["youtube-slot"] = function () { AlmaYouTube.send("toggle"); };
    row(["youtube-slot"]);
    var controls = [
      ["youtube-play", "Reproducir", function () { AlmaYouTube.send("play"); }],
      ["youtube-pause", "Pausar", function () { AlmaYouTube.send("pause"); }],
      ["youtube-back", "\u2212" + prefs.seekStep + " s", function () { AlmaYouTube.send("back", prefs.seekStep); }],
      ["youtube-forward", "+" + prefs.seekStep + " s", function () { AlmaYouTube.send("forward", prefs.seekStep); }],
      ["youtube-seek-step", "Saltos: " + prefs.seekStep + " s", cycleSeekStep],
      ["youtube-full", "Pantalla completa", function () { youtubeFullscreen(true); }],
      ["youtube-retry", "Reintentar", function () { openYoutube(youtubeSelection); }]
    ], ids = [];
    for (var i = 0; i < controls.length; i++) {
      h += pill(controls[i][0], controls[i][1], controls[i][2]); ids.push(controls[i][0]);
    }
    row(ids);
    var isDM=youtubeSelection && youtubeSelection.provider==="dailymotion";
    h += '</div><div class="youtube-options">' + (isDM?"":pill("youtube-native", "Abrir app de YouTube", function () { launch(apps[1]); })) + pill("youtube-return", "Volver a Multimedia", function () { if (!AlmaYouTube.snapshot().ready) closeYoutube(); go("media"); }) + '</div>';
    row(isDM?["youtube-return"]:["youtube-native", "youtube-return"]);
    return h;
  }
  function youtubeHidden() { if (document.hidden) closeYoutube(); }
  function mediaClock(seconds) {
    seconds = Math.max(0, Math.floor(seconds || 0));
    return pad(Math.floor(seconds / 60)) + ":" + pad(seconds % 60);
  }
  function fullscreenVideo(enabled) {
    var video = el("media-video"), player = AlmaPlayer.snapshot();
    if (enabled && (player.kind !== "video" || player.index < 0)) {
      notice("Primero selecciona un v\u00eddeo de la lista.");
      return;
    }
    var resume = !video.paused;
    videoFull = enabled;
    el(enabled ? "stage" : "safe").appendChild(video);
    video.className = enabled ? "video-full" : "";
    if (resume && typeof video.play === "function") {
      try {
        var result = video.play();
        if (result && result.catch) result.catch(function () {});
      } catch (e) {}
    }
    el("video-help").textContent = "Aceptar: reproducir o pausar \u00b7 \u25c0 / \u25b6: " + prefs.seekStep + " segundos \u00b7 Volver: reducir";
    el("video-help").style.display = enabled ? "block" : "none";
  }
  function updatePlayer() {
    if (typeof AlmaPlayer === "undefined") return;
    var player = AlmaPlayer.snapshot();
    if (player.playing && youtubeLoaded) closeYoutube();
    if (videoFull && (state.view !== "media" || player.kind !== "video" || player.index < 0)) fullscreenVideo(false);
    var playing = player.playing ? "true" : "false";
    if (el("safe").getAttribute("data-playing") !== playing)
      el("safe").setAttribute("data-playing", playing);
    htmlIfChanged(el("media-title"), esc(player.title));
    htmlIfChanged(el("media-state"), esc(player.error || player.status));
    htmlIfChanged(
      el("media-time"),
      mediaClock(player.time) + " / " + mediaClock(player.duration)
    );
    htmlIfChanged(el("media-play"), player.playing ? "Pausar" : "Reproducir");
    htmlIfChanged(
      el("media-volume"),
      "Volumen: " + Math.round(player.volume * 100) + " %"
    );
    // Keep the active video attached and laid out while browsing other views.
    // Some legacy engines suspend media when display is set to none.
    el("media-video").style.display =
      player.kind === "video" && player.index >= 0 ? "block" : "none";
    el("media-video").style.visibility = state.view === "media" || state.view === "home" ? "visible" : "hidden";
    var active = player.index >= 0;
    if (youtubeLoaded) {
      el("media-video").style.visibility = "hidden";
      el("safe").setAttribute("data-home-media", "youtube");
      updateYoutube();
      return;
    }
    el("safe").setAttribute("data-home-media", active ? player.kind : "none");
    htmlIfChanged(el("home-media-title"), esc(active ? player.title : "Tu m\u00fasica y tus v\u00eddeos"));
    htmlIfChanged(el("home-media-state"), esc(active ? (player.error || player.status) : "Selecciona un archivo desde Multimedia."));
    var slot = el("home-player"), video = el("media-video");
    if (!videoFull) {
      video.style.left = ""; video.style.top = "";
      video.style.width = ""; video.style.height = ""; video.style.clip = "";
      if (state.view === "home" && slot && active && player.kind === "video") {
        var box = slot.getBoundingClientRect(), safeBox = el("safe").getBoundingClientRect();
        var scale = el("safe").offsetWidth / safeBox.width;
        video.style.left = (box.left - safeBox.left) * scale + "px";
        video.style.top = (box.top - safeBox.top) * scale + "px";
        video.style.width = box.width * scale + "px";
        video.style.height = box.height * scale + "px";
        var viewport = el("view").getBoundingClientRect();
        var clipTop = Math.max(0, Math.min(box.height, viewport.top - box.top)) * scale;
        var clipBottom = Math.max(clipTop, Math.min(box.height, viewport.bottom - box.top) * scale);
        video.style.clip = "rect(" + clipTop + "px," + box.width * scale + "px," + clipBottom + "px,0px)";
      }
    }
    if (el("media-progress"))
      el("media-progress").style.width =
        (player.duration ? (player.time / player.duration) * 100 : 0) + "%";
  }
  function loadMacYoutube(silent) {
    if (macLinksBusy) return;
    macLinksBusy = true;
    macLinksLast = new Date().getTime();
    macLinksHost = prefs.macIp;
    var gen = generation;
    if (!silent) htmlIfChanged(el("mac-links-state"), "Actualizando enlaces de la Mac\u2026");
    request("GET", "http://" + prefs.macIp + ":8088/youtube/library", function (code, body) {
      macLinksBusy = false;
      if (gen !== generation) return;
      var changed = false, success = false;
      try {
        var data = JSON.parse(body);
        if (code !== 200 || Object.prototype.toString.call(data.items) !== "[object Array]") throw new Error();
        var next = data.items.slice(0, 50).filter(function (item) {
          return item && typeof item.id === "string" && (item.provider === "dailymotion" ? /^[A-Za-z0-9]{5,12}$/ : /^[A-Za-z0-9_-]{11}$/).test(item.id) && typeof item.name === "string" && item.name.length <= 80;
        });
        changed = JSON.stringify(next) !== JSON.stringify(macYoutubeLinks);
        macYoutubeLinks = next;
        success = true;
        macLinksState = "Enlaces de la Mac: " + next.length + ". P\u00e9galos en http://" + prefs.macIp + ":8088/enlaces";
      } catch (e) {
        macLinksState = "No se pudo actualizar la lista de la Mac. Comprueba el puente actualizado. Los enlaces anteriores pueden estar desactualizados.";
      }
      if (changed && (state.view === "media" || state.view === "youtube-list") && !modal) render();
      else htmlIfChanged(el("mac-links-state"), esc(macLinksState));
      if (!silent && !success) notice("No se pudo actualizar la lista. Comprueba el puente de la Mac.");
      if (!silent && success && state.view === "media" && !modal) {
        if (macYoutubeLinks.length) {
          for (var r = 0; r < rows.length; r++) {
            var c = rows[r].indexOf("mac-youtube-0");
            if (c >= 0) { state.row = r; state.col = c; focus(); break; }
          }
        } else notice("A\u00fan no hay enlaces en la Mac. A\u00f1\u00e1delos en http://" + prefs.macIp + ":8088/enlaces");
      }
    });
  }
  function loadMacMedia() {
    var base = "http://" + prefs.macIp + ":8088";
    request("GET", base + "/media/library", function (code, body) {
      try {
        var data = JSON.parse(body);
        if (code !== 200 || !data.enabled || !data.items) throw new Error();
        var retained = prefs.media.filter(function (t) {
            return t.url.indexOf("/media/file/") === -1;
          }),
          added = [];
        for (
          var i = 0;
          i < data.items.length && retained.length + added.length < 30;
          i++
        ) {
          var file = data.items[i];
          if (/^[a-f0-9]{16}$/.test(file.id))
            added.push({
              name: String(file.name).slice(0, 80),
              url: base + "/media/file/" + file.id,
              kind: file.kind === "video" ? "video" : "audio"
            });
        }
        prefs.media = retained.concat(added);
        save();
        AlmaPlayer.setTracks(mediaTracks());
        render();
        notice(
          added.length
            ? "Archivos de la Mac a\u00f1adidos a tu lista."
            : "La carpeta de la Mac no contiene archivos compatibles."
        );
      } catch (e) {
        notice(
          "No se pudo leer la carpeta de la Mac. Inicia el puente con --media-dir y comprueba su direcci\u00f3n IP."
        );
      }
    });
  }
  function mediaView() {
    var player = AlmaPlayer.snapshot();
    if (player.playing && youtubeLoaded) closeYoutube();
    var h =
      head(
        "M\u00daSICA Y V\u00cdDEOS",
        "Tu reproductor \u00b7 Alma TV 9.1.2",
        "Archivos propios, enlaces directos y YouTube integrado experimental mediante el puente de la Mac."
      ) +
      '<div class="media-stage"><div class="media-symbol"><span class="media-eq"><b></b><b></b><b></b></span></div><h2 id="media-title">' +
      esc(player.title) +
      '</h2><p id="media-state">' +
      esc(player.error || player.status) +
      '</p><div class="media-track"><span id="media-progress"></span></div><div id="media-time">' +
      mediaClock(player.time) +
      " / " +
      mediaClock(player.duration) +
      '</div></div><div class="media-controls">';
    h +=
      pill("media-prev", "Anterior", function () {
        AlmaPlayer.step(-1);
      }) +
      pill(
        "media-play",
        player.playing ? "Pausar" : "Reproducir",
        AlmaPlayer.toggle
      ) +
      pill("media-next", "Siguiente", function () {
        AlmaPlayer.step(1);
      }) +
      pill("media-seek-step", "Saltos: " + prefs.seekStep + " s", cycleSeekStep) +
      pill("media-back", "\u2212" + prefs.seekStep + " s", function () {
        AlmaPlayer.seek(-prefs.seekStep);
      }) +
      pill("media-forward", "+" + prefs.seekStep + " s", function () {
        AlmaPlayer.seek(prefs.seekStep);
      }) +
      pill("media-stop", "Detener", AlmaPlayer.stop) +
      pill("media-fullscreen", "Pantalla completa", function () { fullscreenVideo(true); });
    row([
      "media-prev",
      "media-play",
      "media-next",
      "media-seek-step",
      "media-back",
      "media-forward",
      "media-stop",
      "media-fullscreen"
    ]);
    h +=
      '</div><div class="media-actions">' +
      pill("media-add", "A\u00f1adir enlace", function () {
        if (prefs.media.length >= 30) {
          notice("Puedes guardar hasta 30 archivos.");
          return;
        }
        editor("mediaName", "Nombre del archivo", "", "text");
      }) +
      pill("media-mac", "Archivos de la Mac", loadMacMedia) +
      pill("media-mac-links", "Enlaces de la Mac", function () { loadMacYoutube(false); }) +
      pill("media-youtube", "YouTube en l\u00ednea", function () { editor("youtubeUrl", "Pega un enlace de YouTube", "", "text"); }) +
      pill("media-youtube-test", "Probar YouTube", function () { openYoutube({ id: "M7lc1UVf-VE", name: "Prueba de compatibilidad de YouTube" }); }) +
      pill("media-vol-down", "\u2212 Volumen", function () {
        setAppAudio(-10, false);
      }) +
      pill("media-vol-up", "+ Volumen", function () {
        setAppAudio(10, false);
      }) +
      '<span id="media-volume">Volumen: ' +
      Math.round(player.volume * 100) +
      ' %</span></div><div class="media-list">';
    row(["media-add", "media-mac", "media-mac-links", "media-youtube", "media-youtube-test", "media-vol-down", "media-vol-up"]);
    for (var i = 0; i < player.tracks.length; i++)
      (function (i) {
        h += button(
          "media-item-" + i,
          player.tracks[i].name,
          player.tracks[i].kind === "video" ? "V\u00eddeo" : "Audio",
          function () {
            AlmaPlayer.play(i);
          },
          "card media-item"
        );
        var ids = ["media-item-" + i];
        if (i > 0) {
          h += pill("media-remove-" + i, "Quitar", function () {
            AlmaPlayer.stop();
            prefs.media.splice(i - 1, 1);
            save();
            AlmaPlayer.setTracks(mediaTracks());
            render();
          });
          ids.push("media-remove-" + i);
        }
        row(ids);
        h += "<br>";
      })(i);
    for (var y = 0; y < prefs.youtubeLinks.length; y++) {
      (function (y) {
        var item = prefs.youtubeLinks[y];
        h += button("youtube-item-" + y, item.name, (item.provider==="dailymotion"?"Dailymotion integrado \u00b7 experimental":"YouTube integrado \u00b7 experimental"), function () { openYoutube(item); }, "card media-item") + pill("youtube-remove-" + y, "Quitar", function () { prefs.youtubeLinks.splice(y, 1); save(); render(); });
        row(["youtube-item-" + y, "youtube-remove-" + y]); h += "<br>";
      })(y);
    }
    h += '<h2 class="mac-links-heading">YouTube \u00b7 Enlaces de la Mac</h2><p id="mac-links-state" class="mac-links-state">' + esc(macLinksState) + '</p>';
    for (var m = 0; m < macYoutubeLinks.length; m++) {
      (function (m) {
        var item = macYoutubeLinks[m];
        h += button("mac-youtube-" + m, item.name, (item.provider==="dailymotion"?"Guardado desde la Mac \u00b7 Dailymotion":"Guardado desde la Mac \u00b7 YouTube"), function () { openYoutube(item); }, "card media-item") + "<br>";
        row(["mac-youtube-" + m]);
      })(m);
    }
    return h + "</div>";
  }
  function render() {
    rendering = true;
    youtubeLayoutKey = "";
    if (state.view === "calibrate") closeYoutube();
    if (youtubeFull && state.view !== "youtube") youtubeFullscreen(false);
    rows = [];
    actions = {};
    nav();
    var viewChanged = lastRenderedView !== state.view;
    if (viewChanged && state.view === "media") macLinksLast = 0;
    var previousMediaList = state.view === "media" && el("view").querySelector(".media-list");
    var previousMediaScroll = previousMediaList ? previousMediaList.scrollTop : 0;
    var h = "";
    switch (state.view) {
      case "home":
        h = home();
        break;
      case "media":
        h = mediaView();
        break;
      case "youtube-list":
        h = youtubeList();
        break;
      case "youtube":
        h = youtubeView();
        break;
      case "apps":
        h = catalog("apps");
        break;
      case "tools":
        h = catalog("tools");
        break;
      case "settings":
        h = settings();
        break;
      case "timer":
        h = timerView();
        break;
      case "calendar":
        h = calendarView();
        break;
      case "network":
        h = networkView();
        break;
      case "weather":
        h = weatherView();
        break;
      case "calibrate":
        h = calibration();
        break;
      case "search":
        h = search();
        break;
      case "links":
        h = linksView();
        break;
      case "pair-phone":
        h = AlmaHub.pairMarkup();
        break;
      case "clock":
        h =
          head("AHORA", "Un momento para ti", "Hora y fecha del televisor") +
          '<div class="big-clock" id="live-clock">' +
          time() +
          '</div><div class="date">' +
          date() +
          "</div>";
        break;
      case "saver":
        h =
          '<div class="saver" id="saver-scene"><div id="saver-clock" class="saver-clock"></div></div>';
        break;
    }
    el("safe").setAttribute("data-view", state.view);
    syncBackgrounds();
    el("view").className = state.view === "saver" ? "saver-view" : (state.view === "home" ? "home-scroll" : "content-scroll");
    if (viewChanged) el("view").scrollTop = 0;
    el("view").onscroll = function () { if (state.view === "home") updatePlayer(); else if (youtubeLoaded) updateYoutube(); };
    el("header").style.display = state.view === "saver" ? "none" : "block";
    el("footer").style.display = state.view === "saver" ? "none" : "block";
    el("view").innerHTML =
      '<div class="page-surface' +
      (viewChanged && prefs.animations && state.view !== "saver" && state.view !== "youtube" && !youtubeLoaded
        ? " page-enter"
        : "") +
      '">' +
      h +
      "</div>";
    var surface = el("view").firstChild;
    surface.addEventListener("animationend", updateYoutube, false);
    surface.addEventListener("webkitAnimationEnd", updateYoutube, false);
    if (state.view === "media" && el("view").querySelector(".media-list")) el("view").querySelector(".media-list").scrollTop = previousMediaScroll;
    lastRenderedView = state.view;
    if (
      state.view === "saver" &&
      typeof AlmaMedia !== "undefined" &&
      /^assets\/salvapantallas\.(jpg|png)$/.test(AlmaMedia.saver)
    ) {
      el("saver-scene").style.backgroundImage = prefs.saverFrame
        ? "url(" + AlmaMedia.saver + ")"
        : "none";
      el("saver-scene").className =
        "saver" + (prefs.saverFrame ? " framed" : "");
    }
    if (state.view === "home") updateHero(heroIndex);
    updateCal();
    updatePlayer();
    if (state.view === "youtube" && youtubeSelection) {
      if (youtubeLoaded !== youtubeSelection.id) {
        youtubeLoaded = youtubeSelection.id;
        AlmaYouTube.open(el("youtube-host"), prefs.macIp, youtubeSelection.id, updateYoutube, youtubeSelection.provider, youtubeSelection.remoteAutoplay);
      }
      updateYoutube();
      setTimeout(function () { if (state.view === "youtube") updateYoutube(); }, 250);
    }
    tick();
    if (viewChanged && state.view === "youtube-list") loadMacYoutube(true);
    if (youtubeLoaded) updateYoutube();
    if (viewChanged && state.view === "home" && youtubeLoaded) {
      for (var homeRow = 0; homeRow < rows.length; homeRow++) if (rows[homeRow][0] === "home-player") { state.row = homeRow; state.col = 0; break; }
    }
    if (!modal) focus();
    rendering = false;
    if (youtubeLoaded) updateYoutube();
    if (typeof AlmaHub !== "undefined") AlmaHub.onRender();
  }
  function focusedId() {
    return rows[state.row] && rows[state.row][state.col];
  }
  function focus() {
    state.row = clamp(state.row, 0, rows.length - 1);
    state.col = clamp(state.col, 0, rows[state.row].length - 1);
    var target = el(focusedId());
    if (target === focusedNode) return;
    if (focusedNode)
      focusedNode.className = focusedNode.className.replace(
        /\s*(focus|press-a|press-b)\b/g,
        ""
      );
    if (target) {
      target.className += " focus";
      focusedNode = target;
      if (state.view === "home" && /^app-\d+$/.test(target.id))
        updateHero(Number(target.id.slice(4)));
      if (!api && !edit && target.focus) target.focus();
      var parent = target.parentNode;
      while (parent && parent !== el("view")) {
        if (parent.className && /app-carousel/.test(parent.className)) {
          var left = target.offsetLeft;
          if (left < parent.scrollLeft)
            parent.scrollLeft = Math.max(0, left - 4);
          else if (
            left + target.offsetWidth >
            parent.scrollLeft + parent.clientWidth
          )
            parent.scrollLeft =
              left + target.offsetWidth - parent.clientWidth + 4;
        }

        if (
          parent.className &&
          /(grid|search-layout|media-list)/.test(parent.className)
        ) {
          var top = target.offsetTop - parent.offsetTop;
          if (top < parent.scrollTop) parent.scrollTop = top - 5;
          else if (
            top + target.offsetHeight >
            parent.scrollTop + parent.clientHeight
          )
            parent.scrollTop =
              top + target.offsetHeight - parent.clientHeight + 8;
        }
        parent = parent.parentNode;
      }
      if (el("view").contains(target)) {
        var viewport = el("view"), visible = viewport.getBoundingClientRect();
        var bounds = target.getBoundingClientRect();
        var ratio = viewport.offsetHeight / visible.height;
        if (target.id === "hero-cta") viewport.scrollTop = 0;
        else if (bounds.top < visible.top) viewport.scrollTop -= (visible.top - bounds.top) * ratio + 8;
        else if (bounds.bottom > visible.bottom) viewport.scrollTop += (bounds.bottom - visible.bottom) * ratio + 8;
        updatePlayer();
        if (youtubeLoaded) updateYoutube();
      }
    }
  }
  function go(view) {
    if (state.view === view) {
      state.row = 1;
      state.col = 0;
      render();
      return;
    }
    stack.push(copy(state));
    if (stack.length > 20) stack.shift();
    state = { view: view, row: 1, col: 0 };
    render();
    if (view === "saver" && prefs.bridge && prefs.city) getWeather(true);
  }
  function back() {
    if (youtubeFull) { youtubeFullscreen(false); return; }
    if (videoFull) { fullscreenVideo(false); return; }
    if (modal) {
      closeDialog();
      return;
    }
    if (state.view === "calibrate" && cal) {
      prefs = cal;
      cal = null;
      apply();
    }
    state = stack.length ? stack.pop() : { view: "home", row: 0, col: 0 };
    render();
  }
  function showDialog(title, body, buttons) {
    if (youtubeLoaded) { AlmaYouTube.send("pause"); el("youtube-host").style.visibility = "hidden"; }
    modal = { state: copy(state), rows: rows, actions: actions };
    rows = [];
    actions = {};
    state = { view: state.view, row: 0, col: 0 };
    var h =
        "<h2>" +
        esc(title) +
        "</h2><p>" +
        esc(body) +
        '</p><div class="actions">',
      ids = [];
    for (var i = 0; i < buttons.length; i++) {
      h += pill("dialog-" + i, buttons[i].label, buttons[i].action);
      ids.push("dialog-" + i);
    }
    row(ids);
    el("dialog").innerHTML = h + "</div>";
    el("dialog").style.display = "block";
    focus();
  }
  function closeDialog() {
    if (!modal) return;
    state = modal.state;
    rows = modal.rows;
    actions = modal.actions;
    modal = null;
    edit = null;
    el("dialog").style.display = "none";
    render();
  }
  function reset() {
    showDialog(
      "Restaurar Alma TV",
      "Se borrar\u00e1n solo la calibraci\u00f3n, IP, ciudad y enlaces de Alma TV. Las aplicaciones y los datos de Smart Hub se conservan.",
      [
        { label: "Cancelar", action: closeDialog },
        {
          label: "Restaurar preferencias",
          action: function () {
            prefs = copy(defaults);
            AlmaPlayer.stop();
            AlmaPlayer.setTracks(mediaTracks());
            save();
            invalidate();
            apply();
            closeDialog();
            notice("Preferencias de Alma TV restauradas");
          }
        }
      ]
    );
  }
  function editor(field, title, value, type) {
    edit = { field: field, value: String(value), type: type, title: title };
    if (youtubeLoaded) { AlmaYouTube.send("pause"); el("youtube-host").style.visibility = "hidden"; }
    modal = { state: copy(state), rows: rows, actions: actions };
    state = { view: state.view, row: 0, col: 0 };
    drawEditor();
  }
  function drawEditor() {
    rows = [];
    actions = {};
    var h =
        "<h2>" +
        esc(edit.title) +
        '</h2><input class="field" id="editor-value" type="text" autocomplete="off" value="' +
        esc(edit.value) +
        '"><div class="keyboard">',
      chars =
        edit.type === "ip"
          ? ["1234567890."]
          : [
              "ABCDEFGHIJKLM",
              "NOPQRSTUVWXYZ",
              "\u00d1\u00c1\u00c9\u00cd\u00d3\u00da\u00dc",
              "0123456789.:/-",
              "?&_=%,+#@"
            ],
      i,
      j,
      ids;
    for (i = 0; i < chars.length; i++) {
      ids = [];
      for (j = 0; j < chars[i].length; j++) {
        (function (c, i, j) {
          var id = "key-" + i + "-" + j;
          actions[id] = function () {
            append(c.toLowerCase());
          };
          h +=
            '<button id="' +
            id +
            '" data-focus="' +
            id +
            '" class="key">' +
            esc(c) +
            "</button>";
          ids.push(id);
        })(chars[i].charAt(j), i, j);
      }
      row(ids);
      h += "<br>";
    }
    h += "</div>";
    ids = [];
    [
      [
        "space",
        "Espacio",
        function () {
          append(" ");
        }
      ],
      [
        "delete",
        "Borrar",
        function () {
          edit.value = edit.value.slice(0, -1);
          updateEdit();
        }
      ],
      ["done", "Guardar", finishEdit],
      ["cancel", "Cancelar", closeDialog]
    ].forEach(function (b) {
      if (edit.type === "ip" && b[0] === "space") return;
      h += pill("edit-" + b[0], b[1], b[2]) + " ";
      ids.push("edit-" + b[0]);
    });
    row(ids);
    h +=
      '<p class="help">Flechas y Aceptar para escribir \u00b7 teclado f\u00edsico opcional \u00b7 Volver cancela</p>';
    el("dialog").innerHTML = h;
    el("dialog").style.display = "block";
    el("editor-value").oninput = function () {
      if (edit)
        edit.value = this.value.slice(
          0,
          (edit.field === "mediaUrl" || edit.field === "youtubeUrl") || edit.field === "linkUrl"
            ? 1000
            : edit.type === "ip"
              ? 15
              : 80
        );
    };
    el("editor-value").focus();
    focus();
  }
  function updateEdit() {
    el("editor-value").value = edit.value;
  }
  function append(s) {
    var max =
      edit.field === "linkUrl" || (edit.field === "mediaUrl" || edit.field === "youtubeUrl")
        ? 1000
        : edit.type === "ip"
          ? 15
          : 80;
    if (edit.value.length < max) {
      edit.value += s;
      updateEdit();
    }
  }
  var linkName = "",
    mediaName = "";
  function finishEdit() {
    var f = edit.field,
      v = edit.value.replace(/^\s+|\s+$/g, "");
    if ((f === "tvIp" || f === "macIp") && !privateIp(v)) {
      notice("Usa una direcci\u00f3n IPv4 privada v\u00e1lida");
      return;
    }
    if (f === "youtubeUrl") {
      if (saveYoutube(v, "")) closeDialog();
      return;
    }
    if (f === "mediaName") {
      if (!v) {
        notice("Escribe un nombre para el archivo.");
        return;
      }
      mediaName = v;
      closeDialog();
      editor(
        "mediaUrl",
        "Enlace directo al archivo de audio o video",
        "",
        "text"
      );
      return;
    }
    if (f === "mediaUrl") {
      if (!validUrl(v)) {
        notice("Introduce una direcci\u00f3n http:// o https:// v\u00e1lida.");
        return;
      }
      if (AlmaYouTube.parseUrl(v)) {
        if (saveYoutube(v, mediaName)) closeDialog();
        return;
      }
      if (/youtube\.com|youtu\.be|spotify\.com/i.test(v)) {
        notice(
          "Usa un enlace directo a un archivo MP3 o MP4. Los enlaces de YouTube y Spotify no son archivos reproducibles."
        );
        return;
      }
      prefs.media.push({
        name: mediaName,
        url: v,
        kind: /\.(mp4|m4v|webm)([?#]|$)/i.test(v) ? "video" : "audio"
      });
      save();
      AlmaPlayer.setTracks(mediaTracks());
      closeDialog();
      return;
    }
    if (f === "linkName") {
      if (!v) {
        notice("Escribe un nombre");
        return;
      }
      linkName = v;
      closeDialog();
      editor("linkUrl", "URL completa http:// o https://", "", "text");
      return;
    }
    if (f === "linkUrl") {
      if (!validUrl(v)) {
        notice("Escribe una URL http:// o https:// v\u00e1lida");
        return;
      }
      prefs.links.push({ name: linkName, url: v });
      save();
      closeDialog();
      return;
    }
    if (f === "query") {
      query = v;
      closeDialog();
      return;
    }
    prefs[f] = v;
    save();
    if (f === "tvIp" || f === "macIp" || f === "city") {
      invalidate();
    }
    if (f === "city")
      weather = {
        text: "Sin datos",
        detail: "Actualiza para consultar la ciudad configurada."
      };
    closeDialog();
  }
  function invalidate() {
    generation++;
    for (var i = 0; i < requests.length; i++) {
      try {
        requests[i].abort();
      } catch (e) {}
    }
    requests = [];
    pending = false;
    weatherPending = false;
    macLinksBusy = false;
    macLinksLast = 0;
    net = { YouTube: "Sin comprobar", Netflix: "Sin comprobar" };
  }
  function request(method, url, callback, body) {
    var x = new XMLHttpRequest(),
      done = false,
      t = null;
    function finish(status, text) {
      if (done) return;
      done = true;
      clearTimeout(t);
      var i = requests.indexOf(x);
      if (i !== -1) requests.splice(i, 1);
      callback(status, text);
    }
    try {
      x.open(method, url, true);
      if (body) x.setRequestHeader("Content-Type", "application/json");
      x.onreadystatechange = function () {
        if (x.readyState === 4) finish(x.status, x.responseText);
      };
      x.onerror = function () {
        finish(0, "");
      };
      t = setTimeout(function () {
        finish(0, "");
        try {
          x.abort();
        } catch (e) {}
      }, 6000);
      requests.push(x);
      x.send(body ? JSON.stringify(body) : (method === "POST" ? "" : null));
    } catch (e) {
      finish(0, "");
    }
    return x;
  }
  function endpoint(name) {
    return prefs.relay
      ? "http://" +
          prefs.macIp +
          ":8088/dial/" +
          name +
          "?tv=" +
          encodeURIComponent(prefs.tvIp)
      : "http://" + prefs.tvIp + ":8080/ws/app/" + name;
  }
  function statusText(code, body) {
    if (code === 200) {
      var m = body.match(/<(?:\w+:)?state[^>]*>([^<]+)</i);
      return m ? "Disponible \u00b7 " + m[1] : "Disponible \u00b7 HTTP 200";
    }
    return code ? "No disponible \u00b7 HTTP " + code : "Sin respuesta \u00b7 red o CORS";
  }
  function updateNetwork() {
    htmlIfChanged(
      el("network"),
      net.YouTube.indexOf("Disponible") === 0 ||
        net.Netflix.indexOf("Disponible") === 0
        ? "Televisor conectado"
        : "Conexi\u00f3n sin comprobar"
    );
    htmlIfChanged(el("dial-youtube"), esc(net.YouTube));
    htmlIfChanged(el("dial-netflix"), esc(net.Netflix));
  }
  function checkNetwork() {
    var gen = generation;
    ["YouTube", "Netflix"].forEach(function (name) {
      net[name] = "Comprobando\u2026";
      request("GET", endpoint(name), function (code, body) {
        if (gen !== generation) return;
        net[name] = statusText(code, body);
        updateNetwork();
        if (state.view === "apps" && !modal) render();
      });
    });
    updateNetwork();
  }
  function launch(a) {
    closeYoutube();
    if (a.dial) {
      if (pending) {
        notice("Solicitud en curso\u2026");
        return;
      }
      pending = true;
      AlmaPlayer.pause();
      var gen = generation;
      notice("Abriendo " + a.name + "\u2026");
      request("POST", endpoint(a.dial), function (code) {
        if (gen !== generation) return;
        pending = false;
        if (code === 200 || code === 201 || code === 204)
          notice(
            "DIAL acept\u00f3 la solicitud de " + a.name + ". Comprueba la TV."
          );
        else
          notice(
            "No se pudo abrir " +
              a.name +
              " \u00b7 " +
              (code ? "HTTP " + code : "sin respuesta, red o CORS") +
              ". Revisa Diagn\u00f3stico."
          );
      });
    } else if (a.id === "xbox") {
      openXbox();
    } else if (a.id === "browser") {
      browser("https://example.com");
    } else if (a.id === "more") {
      go("apps");
    } else {
      showDialog(
        a.name +
          (/^(prime|disney)$/.test(a.id)
            ? " \u00b7 sin soporte nativo"
            : " \u00b7 integraci\u00f3n sin verificar"),
        "No hay una aplicaci\u00f3n compatible confirmada para este televisor Orsay. Un acceso en Alma TV no a\u00f1ade el reproductor ni el DRM que requiere el servicio. Puedes utilizar un dispositivo HDMI compatible con su app oficial.",
        [
          { label: "Volver", action: closeDialog },
          {
            label: "Xbox \u00b7 HDMI 2",
            action: function () {
              closeDialog();
              openXbox();
            }
          }
        ]
      );
    }
  }
  var hdmiPending = false;
  function openXbox() {
    var tvWindow =
      typeof webapis !== "undefined" && webapis.tv && webapis.tv.window;
    if (
      !tvWindow ||
      typeof tvWindow.getAvailableSources !== "function" ||
      typeof tvWindow.setSource !== "function"
    ) {
      showDialog(
        "Xbox \u00b7 HDMI 2",
        "Este firmware no expone la selecci\u00f3n de entradas a Alma TV. Enciende la consola y elige HDMI 2 con el bot\u00f3n SOURCE del control Samsung. La entrada actual no se ha cambiado.",
        [{ label: "Volver", action: closeDialog }]
      );
      return;
    }
    if (hdmiPending) return;
    hdmiPending = true;
    var done = false,
      deadline = setTimeout(function () {
        fail("La API no respondi\u00f3. Usa SOURCE \u2192 HDMI 2.");
      }, 6000);
    function fail(message) {
      if (done) return;
      done = true;
      hdmiPending = false;
      clearTimeout(deadline);
      notice(message);
    }
    function sourcesAvailable(sources) {
      if (done) return;
      if (typeof sources === "string") {
        try {
          sources = JSON.parse(sources);
        } catch (e) {
          fail("No se pudo interpretar la lista de entradas.");
          return;
        }
      }
      if (sources && sources.sources) sources = sources.sources;
      if (Object.prototype.toString.call(sources) !== "[object Array]") {
        fail("La lista de entradas no es compatible. Usa SOURCE \u2192 HDMI 2.");
        return;
      }
      var selected = null;
      for (var i = 0; i < sources.length; i++) {
        var source = sources[i],
          type = String(source.type || "").toUpperCase(),
          name = String(source.name || source.id || "")
            .toUpperCase()
            .replace(/\s/g, "");
        if (
          (type === "HDMI" && Number(source.number) === 2) ||
          name === "HDMI2"
        ) {
          selected = source;
          break;
        }
      }
      if (!selected) {
        fail("HDMI 2 no aparece entre las entradas disponibles.");
        return;
      }
      try {
        AlmaPlayer.pause();
        tvWindow.setSource(
          selected,
          function () {
            if (done) return;
            done = true;
            hdmiPending = false;
            clearTimeout(deadline);
            notice("La TV acept\u00f3 HDMI 2. La consola debe estar encendida.");
          },
          function () {
            fail("No se pudo seleccionar HDMI 2. Usa SOURCE en el control.");
          }
        );
      } catch (error) {
        fail("El firmware rechaz\u00f3 el cambio a HDMI 2.");
      }
    }
    try {
      tvWindow.getAvailableSources(sourcesAvailable, function () {
        fail("No se pudo consultar las entradas de la TV.");
      });
    } catch (error) {
      fail("La API de entradas no est\u00e1 disponible en este firmware.");
    }
  }
  function browser(url) {
    try {
      if (api && typeof api.runWebBrowser === "function") {
        api.runWebBrowser(url, "");
      } else notice("Navegador Samsung no disponible en esta previsualizaci\u00f3n");
    } catch (e) {
      notice("No se pudo abrir el navegador Samsung");
    }
  }
  var weatherPending = false;
  function getWeather(silent) {
    if (weatherPending) return;
    if (!prefs.city) {
      notice("Configura ciudad y pa\u00eds primero");
      return;
    }
    if (!prefs.bridge) {
      weather = {
        text: "Sin datos",
        detail:
          "Activa el puente local en Ajustes e inicia puente.py en la Mac."
      };
      render();
      return;
    }
    weatherPending = true;
    weather = {
      text: "Consultando\u2026",
      detail: "Open-Meteo v\u00eda Mac \u00b7 sin ubicaci\u00f3n autom\u00e1tica"
    };
    if (!silent) render();
    var gen = generation;
    request(
      "GET",
      "http://" +
        prefs.macIp +
        ":8088/weather?city=" +
        encodeURIComponent(prefs.city),
      function (code, body) {
        weatherPending = false;
        if (gen !== generation) return;
        try {
          var w = JSON.parse(body);
          if (
            code !== 200 ||
            typeof w.temperature !== "number" ||
            !w.observed_at
          )
            throw new Error();
          weather = {
            text: w.temperature + " \u00b0C \u00b7 " + w.city,
            detail:
              "Observaci\u00f3n: " +
              w.observed_at +
              " \u00b7 " +
              w.description +
              " \u00b7 Open-Meteo (CC BY 4.0)",
            icon: weatherIcon(w.code, w.is_day),
            observed: w.observed_at,
            updated: new Date().getTime()
          };
        } catch (e) {
          weather = {
            text: "Sin datos",
            detail:
              "Puente o proveedor no disponible. No se muestra una temperatura guardada como actual."
          };
        }
        if (state.view === "weather" && !modal) render();
      }
    );
  }
  function weatherIcon(code, day) {
    if (typeof code !== "number") return "cloud";
    if (code === 0 || code === 1) return day === 0 ? "moon" : "sun";
    if (code >= 95) return "storm";
    if (code >= 51 && code <= 82) return "rain";
    return "cloud";
  }
  function saverMarkup() {
    var icon = weather.icon || "cloud",
      w = weather.text || "Sin datos";
    return (
      '<div class="saver-time">' +
      time() +
      '</div><div class="saver-date">' +
      esc(date() + " de " + new Date().getFullYear()) +
      '</div><div class="saver-location">' +
      esc(prefs.city || "Ubicaci\u00f3n no configurada") +
      '</div><div class="saver-weather"><img src="assets/weather/' +
      icon +
      '.png" alt=""><div>' +
      esc(w) +
      "<small>" +
      (weather.observed
        ? "Open-Meteo \u00b7 " + esc(weather.observed)
        : "No hay datos meteorol\u00f3gicos actualizados") +
      "</small></div></div>"
    );
  }
  function tick() {
    pollLive();
    if ((state.view === "media" || state.view === "youtube-list") && !modal && (macLinksHost !== prefs.macIp || new Date().getTime() - macLinksLast >= 15000)) loadMacYoutube(true);
    htmlIfChanged(el("time"), time());
    updateNetwork();
    if (timer.running && timerLeft() <= 0) {
      timer.running = false;
      timer.left = 0;
      timer.finished = true;
      notice("Temporizador terminado");
      if (state.view === "timer" && !modal) {
        render();
        return;
      }
    }
    htmlIfChanged(el("countdown"), timerText());
    htmlIfChanged(el("live-clock"), time());
    if (el("saver-clock")) {
      var d = new Date(),
        s = Math.floor(d.getTime() / 15000);
      htmlIfChanged(el("saver-clock"), saverMarkup());
      if (el("saver-clock")._almaSlot !== s) {
        el("saver-clock").style.left = 80 + (s % 5) * 145 + "px";
        el("saver-clock").style.top = 55 + (s % 4) * 90 + "px";
        el("saver-clock")._almaSlot = s;
      }
      if (
        prefs.bridge &&
        prefs.city &&
        !weatherPending &&
        (!weather.updated || d.getTime() - weather.updated > 600000) &&
        d.getSeconds() === 0
      )
        getWeather(true);
    }
    if (state.view === "home" && !modal) {
      var vals = [
        time(),
        timerText(),
        date().split(",")[0],
        "Iniciar",
        net.YouTube.indexOf("Disponible") === 0
          ? "Televisor conectado"
          : "Sin comprobar",
        weather.text
      ];
      for (var i = 0; i < vals.length; i++) {
        var t = el("tool-" + i);
        if (t) htmlIfChanged(t.getElementsByTagName("small")[0], esc(vals[i]));
      }
    }
  }
  function exit() {
    closeYoutube();
    AlmaPlayer.pause();
    if (api) {
      try {
        api.sendExitEvent();
        return;
      } catch (e) {}
    }
    notice("Se solicit\u00f3 salir \u00b7 el cierre real requiere Samsung Orsay");
  }
  function toggleTVVolume() {
    if (AlmaTVAudio.active()) { AlmaTVAudio.close(); releaseVolumeKeys(); render(); return; }
    var enabled = AlmaTVAudio.init(volumeKeyCodes, notice);
    render();
    notice(enabled ? "Control de volumen de la TV activo. Prueba Vol+, Vol\u2212 y Silencio." : "La TV rechaz\u00f3 el control nativo de volumen.");
  }
  var volumeKeyCodes = [7, 11, 27], nativeKeyPlugin = null;
  function releaseVolumeKeys() {
    if (AlmaTVAudio.active()) return;
    try {
      if (typeof Common === "undefined" || !Common.API) return;
      if (typeof Common.API.TVKeyValue === "function") {
        var keys = new Common.API.TVKeyValue();
        volumeKeyCodes = [typeof keys.KEY_VOL_UP === "number" ? keys.KEY_VOL_UP : 7, typeof keys.KEY_VOL_DOWN === "number" ? keys.KEY_VOL_DOWN : 11, typeof keys.KEY_MUTE === "number" ? keys.KEY_MUTE : 27];
      }
      if (!nativeKeyPlugin && typeof Common.API.Plugin === "function") nativeKeyPlugin = new Common.API.Plugin();
      if (!nativeKeyPlugin || typeof nativeKeyPlugin.unregistKey !== "function") return;
      for (var i = 0; i < volumeKeyCodes.length; i++) {
        try { nativeKeyPlugin.unregistKey(volumeKeyCodes[i]); } catch (unavailableKey) {}
      }
    } catch (unavailablePlugin) {}
  }
  function key(code) {
    // Samsung handles its own amplifier and OSD. Do not consume Vol+/Vol-/Mute.
    if (volumeKeyCodes.indexOf(code) !== -1) return AlmaTVAudio.handle(code);

    var map = {
        4: "left",
        37: "left",
        5: "right",
        39: "right",
        29460: "up",
        38: "up",
        29461: "down",
        40: "down",
        29443: "ok",
        13: "ok",
        88: "back",
        8: "back",
        10009: "back",
        45: "exit",
        20: "home",
        21: "settings"
      },
      k = map[code];
    if (!k) {
      if (edit && code === 32) {
        append(" ");
        return true;
      }
      return false;
    }
    if (youtubeFull) {
      if (k === "back" || k === "exit") youtubeFullscreen(false);
      else if (k === "ok") AlmaYouTube.send("toggle");
      else if (k === "left") AlmaYouTube.send("back", prefs.seekStep);
      else if (k === "right") AlmaYouTube.send("forward", prefs.seekStep);
      else if (k === "home" || k === "settings") { go(k === "home" ? "home" : "settings"); }
      return true;
    }
    if (videoFull) {
      if (k === "back" || k === "exit") fullscreenVideo(false);
      else if (k === "ok") AlmaPlayer.toggle();
      else if (k === "left") AlmaPlayer.seek(-prefs.seekStep);
      else if (k === "right") AlmaPlayer.seek(prefs.seekStep);
      else if (k === "home" || k === "settings") { fullscreenVideo(false); go(k === "home" ? "home" : "settings"); }
      return true;
    }
    if (k === "exit") {
      exit();
      return true;
    }
    if (k === "back") {
      back();
      return true;
    }
    if (k === "home") {
      if (state.view === "calibrate" && !modal) {
        saveCalibration();
        return true;
      }
      if (modal) closeDialog();
      if (cal) {
        prefs = cal;
        cal = null;
        apply();
      }
      go("home");
      return true;
    }
    if (k === "settings") {
      if (modal) closeDialog();
      if (cal) {
        prefs = cal;
        cal = null;
        apply();
      }
      go("settings");
      return true;
    }
    if (state.view === "saver" && !modal) {
      back();
      return true;
    }
    if (state.view === "calibrate" && !modal && state.row === 1) {
      if (k === "up") {
        calAxis = (calAxis + 2) % 3;
      } else if (k === "down") {
        calAxis = (calAxis + 1) % 3;
      } else if (k === "left" || k === "right") {
        var d = k === "left" ? -1 : 1;
        if (calAxis === 0) prefs.scale = clamp(prefs.scale + d, 76, 100);
        else if (calAxis === 1) prefs.x = clamp(prefs.x + d * 2, -40, 40);
        else prefs.y = clamp(prefs.y + d * 2, -30, 30);
        apply();
      } else if (k === "ok") {
        state.row = 2;
        state.col = 0;
        focus();
      }
      updateCal();
      return true;
    }
    if (k === "ok") {
      var fn = actions[focusedId()];
      if (fn) confirmAction(fn);
      return true;
    }
    if (!modal && state.row === 0) {
      if (k === "up") state.col--;
      if (k === "down") state.col++;
      if (k === "right" && rows.length > 1) {
        sidebarIndex = state.col;
        state.row = 1;
        state.col = 0;
      }
      focus();
      return true;
    }
    if (!modal && k === "left" && state.col === 0) {
      state.row = 0;
      state.col = sidebarIndex;
      focus();
      return true;
    }
    if (!modal && k === "up" && state.row === 1) {
      state.row = 0;
      state.col = sidebarIndex;
      focus();
      return true;
    }
    if (k === "left") state.col--;
    if (k === "right") state.col++;
    if (k === "up") state.row--;
    if (k === "down") state.row++;
    focus();
    return true;
  }
  A.init = function () {
    load();
    apply();
    try {
      api = new Common.API.Widget();
      api.sendReadyEvent();
    } catch (e) {}
    releaseVolumeKeys();
    window.addEventListener("focus", releaseVolumeKeys, false);
    window.onresize = fitScreen;
    document.body.appendChild(el("youtube-host"));
    AlmaYouTube.init();
    document.addEventListener("visibilitychange", youtubeHidden, false);
    AlmaPlayer.init(el("media-audio"), el("media-video"), updatePlayer);
    AlmaPlayer.setLevel(prefs.appVolume/100,prefs.appMuted); AlmaYouTube.level(prefs.appVolume,prefs.appMuted,true);
    AlmaPlayer.setTracks(mediaTracks());
    document.onkeydown = function (e) {
      e = e || window.event;
      var used;
      if (edit && e.key && e.key.length === 1 && e.keyCode !== 32) {
        used = false;
      } else if (edit && e.keyCode === 8) {
        edit.value = edit.value.slice(0, -1);
        updateEdit();
        used = true;
      } else used = key(e.keyCode || e.which);
      if (used) {
        try {
          if (api && typeof api.blockNavigation === "function")
            api.blockNavigation(e);
        } catch (ignore) {}
        if (e.preventDefault) e.preventDefault();
        e.returnValue = false;
        return false;
      }
    };
    document.onkeypress = function (e) {
      e = e || window.event;
      if (edit && !e.ctrlKey && !e.metaKey) {
        var c = e.charCode || e.which;
        if (c >= 32 && c <= 65535) {
          if (c !== 32) append(String.fromCharCode(c));
          if (e.preventDefault) e.preventDefault();
          return false;
        }
      }
    };
    document.onclick = function (e) {
      e = e || window.event;
      var t = e.target || e.srcElement;
      while (t && t !== document) {
        var id = t.getAttribute && t.getAttribute("data-focus");
        if (id) {
          for (var i = 0; i < rows.length; i++) {
            var j = rows[i].indexOf(id);
            if (j !== -1) {
              state.row = i;
              state.col = j;
              focus();
              if (actions[id]) confirmAction(actions[id]);
              if (edit && el("editor-value")) el("editor-value").focus();
              return;
            }
          }
        }
        t = t.parentNode;
      }
    };
    if (
      typeof AlmaMedia !== "undefined" &&
      /^assets\/salvapantallas\.(jpg|png)$/.test(AlmaMedia.saver)
    ) {
      el("wallpaper").style.backgroundImage = "url(" + AlmaMedia.saver + ")";
    }
    render();
    interval = setInterval(tick, 1000);
    AlmaHub.start();
  };
  A.destroy = function () {
    AlmaHub.stop();
    AlmaTVAudio.close();
    window.onresize = null;
    window.removeEventListener("focus", releaseVolumeKeys, false);
    AlmaYouTube.destroy();
    document.removeEventListener("visibilitychange", youtubeHidden, false);
    AlmaPlayer.destroy();
    clearInterval(interval);
    clearTimeout(toastTimer);
    invalidate();
  };
  var hubAutoplay = false;
  A.hubConfig = function () {return {macIp:prefs.macIp,view:state.view};};
  A.hubNotice = notice;
  A.hubPhoto = function () {closeYoutube();el("media-video").style.visibility="hidden";go("home");};
  A.hubPlay = function(item, keepView) {
    if(item.kind==="youtube"){
      livePending=null;openYoutube({id:item.video,provider:item.provider,name:item.name},item.mode==="audio",true);hubAutoplay=true;go("home");updateYoutube();
    }else{
      closeYoutube();var url="http://"+prefs.macIp+":8088"+item.path;
      if(!/^\/(?:hub\/(?:file|stream)\/|media\/file\/)[A-Za-z0-9]+$/.test(item.path))throw new Error("Direcci\u00f3n de archivo no v\u00e1lida");
      AlmaPlayer.setTracks([{name:item.name,url:url,kind:item.kind==="video"?"video":"audio"}]);AlmaPlayer.play(0);if(!keepView)go("home");
    }
  };
  function setAppAudio(delta, toggleMute) {
    if (toggleMute) prefs.appMuted = !prefs.appMuted;
    else { prefs.appVolume = clamp(prefs.appVolume + delta,0,100); if(delta>0) prefs.appMuted=false; }
    save(); AlmaPlayer.setLevel(prefs.appVolume/100,prefs.appMuted); AlmaYouTube.level(prefs.appVolume,prefs.appMuted);
  }
  A.hubControl = function(action,seconds,view) {
    var remoteKeys={up:38,down:40,left:37,right:39,ok:13,back:88};
    if(remoteKeys[action]){key(remoteKeys[action]);return;}
    if(action==="navigate"){
      if(["home","search","apps","media","hub","clock","weather","calendar","timer","settings","saver"].indexOf(view)===-1)throw new Error("Men\u00fa no disponible");
      if(view==="hub"){exit();return;}
      if(modal)closeDialog();if(edit){edit=null;}if(youtubeFull)youtubeFullscreen(false);if(videoFull)fullscreenVideo(false);
      sidebarIndex=Math.max(0,navViews.indexOf(view));go(view);return;
    }
    if(action==="fullscreen"){
      if(youtubeLoaded)youtubeFullscreen(!youtubeFull);
      else if(AlmaPlayer.snapshot().kind==="video"&&AlmaPlayer.snapshot().index>=0)fullscreenVideo(!videoFull);
      else throw new Error("No hay un v\u00eddeo abierto para ampliar");return;
    }
    if(action==="home"||action==="media"||action==="saver"){go(action);return;}
    if(action==="volume-up"||action==="volume-down"||action==="mute"){
      setAppAudio(action==="volume-up"?10:action==="volume-down"?-10:0,action==="mute");return;
    }
    if(action==="stop"){hubAutoplay=false;closeYoutube();AlmaPlayer.stop();return;}
    if(youtubeLoaded){if(action==="seek")AlmaYouTube.send(seconds<0?"back":"forward",Math.abs(seconds));else AlmaYouTube.send(action);}
    else if(action==="play")AlmaPlayer.play();else if(action==="pause")AlmaPlayer.pause();else if(action==="toggle")AlmaPlayer.toggle();else if(action==="seek")AlmaPlayer.seek(seconds);
  };
  A.hubRemoteStatus=function(){
    var id=focusedId(),node=id&&el(id),parts=[],children=node?node.children:[],i;
    for(i=0;i<children.length;i++)if(/^(STRONG|SMALL|H2|H3)$/.test(children[i].tagName))parts.push(children[i].textContent);
    return {view:state.view,focus:node?String(parts.length?parts.join(" \u00b7 "):node.textContent||"").replace(/\s+/g," ").slice(0,160):"",focus_id:id||""};
  };
  A.hubStatus = function(){
    if(youtubeLoaded){var value=AlmaYouTube.snapshot();return {title:value.title||(youtubeSelection&&youtubeSelection.name)||"V\u00eddeo",kind:(youtubeSelection&&youtubeSelection.provider)||"youtube",state:value.failed?"Error":(value.state===1?"Reproduciendo":(value.state===2?"En pausa":"Preparado")),seconds:value.seconds||0,duration:value.duration||0,volume:value.volume,muted:value.muted,finished:value.state===0,error:value.failed?value.status:""};}
    var current=AlmaPlayer.snapshot();return {title:current.index>=0?current.title:"Sin reproducci\u00f3n",kind:current.kind,state:current.status,seconds:current.time,duration:current.duration,error:current.error,volume:Math.round(current.volume*100),muted:current.muted};
  };
  A.key = key;
  A.go = go;
  A.checkNetwork = checkNetwork;
  A.ipValid = privateIp;
  return A;
})();
