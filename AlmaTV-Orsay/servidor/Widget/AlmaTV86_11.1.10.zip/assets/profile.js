/* La foto personal se a\u00f1ade solo en la Mac al instalar. */
var AlmaProfile = {image:""};
